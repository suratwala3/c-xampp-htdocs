<?php

namespace App\Http\Controllers;

use App\AcceptDelivery;
use App\Addon;
use App\AddonCategory;
use App\DeliveryGuyDetail;
use App\Helpers\TranslationHelper;
use App\Item;
use App\ItemCategory;
use App\Order;
use App\Orderstatus;
use App\Page;
use App\PaymentGateway;
use App\PopularGeoPlace;
use App\PromoSlider;
use App\PushNotify;
use App\Restaurant;
use App\RestaurantCategory;
use App\RestaurantPayout;
use App\Setting;
use App\Slide;
use App\Sms;
use App\SmsGateway;
use App\Translation;
use App\User;
use Artisan;
use Auth;
use Bavix\Wallet\Models\Transaction;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Image;
use Ixudra\Curl\Facades\Curl;
use Omnipay\Omnipay;
use Spatie\Permission\Models\Role;

class AdminController extends Controller
{
    /**
     * @return mixed
     */
    public function dashboard()
    {
        $displayUsers = User::count();

        $displayRestaurants = Restaurant::count();

        $displaySales = Order::where('orderstatus_id', 5)->get();
        $displayEarnings = $displaySales;

        $displaySales = count($displaySales);

        $total = 0;
        foreach ($displayEarnings as $de) {
            $total += $de->total;
        }
        $displayEarnings = $total;

        $orders = Order::orderBy('id', 'DESC')->with('orderstatus')->take(10)->get();

        $users = User::orderBy('id', 'DESC')->with('roles')->take(10)->get();

        $todaysDate = Carbon::now()->format('Y-m-d');

        $orderStatusesName = '[';

        $orderStatuses = Orderstatus::get(['name'])
            ->pluck('name')
            ->toArray();
        foreach ($orderStatuses as $key => $value) {
            $orderStatusesName .= "'" . $value . "' ,";
        }
        $orderStatusesName = rtrim($orderStatusesName, ' ,');
        $orderStatusesName = $orderStatusesName . ']';

        $orderStatusOrders = Order::all();
        $ifAnyOrders = $orderStatusOrders->count();
        if ($ifAnyOrders == 0) {
            $ifAnyOrders = false;
        } else {
            $ifAnyOrders = true;
        }

        $orderStatusOrders = $orderStatusOrders->groupBy('orderstatus_id')->map(function ($orderCount) {
            return $orderCount->count();
        });

        $orderStatusesData = '[';
        foreach ($orderStatusOrders as $key => $value) {
            if ($key == 1) {
                $orderStatusesData .= '{value:' . $value . ", name: 'Order Placed'},";
            }
            if ($key == 2) {
                $orderStatusesData .= '{value:' . $value . ", name: 'Preparing Order'},";
            }
            if ($key == 3) {
                $orderStatusesData .= '{value:' . $value . ", name: 'Delivery Guy Assigned'},";
            }
            if ($key == 4) {
                $orderStatusesData .= '{value:' . $value . ", name: 'Order Picked Up'},";
            }
            if ($key == 5) {
                $orderStatusesData .= '{value:' . $value . ", name: 'Delivered'},";
            }
            if ($key == 6) {
                $orderStatusesData .= '{value:' . $value . ", name: 'Canceled'},";
            }
        }
        $orderStatusesData = rtrim($orderStatusesData, ',');
        $orderStatusesData .= ']';

        return view('admin.dashboard', array(
            'displayUsers' => $displayUsers,
            'displayRestaurants' => $displayRestaurants,
            'displaySales' => $displaySales,
            'displayEarnings' => $displayEarnings,
            'orders' => $orders,
            'users' => $users,
            'todaysDate' => $todaysDate,
            'orderStatusesName' => $orderStatusesName,
            'orderStatusesData' => $orderStatusesData,
            'ifAnyOrders' => $ifAnyOrders,
        ));
    }

    public function users()
    {

        $users = User::orderBy('id', 'DESC')->with('roles', 'wallet')->paginate(20);
        $count = $users->total();

        $roles = Role::all();
        return view('admin.users', array(
            'count' => $count,
            'users' => $users,
            'roles' => $roles,
        ));
    }

    /**
     * @param Request $request
     */
    public function saveNewUser(Request $request)
    {
        try {
            $user = User::create([
                'name' => $request->name,
                'email' => $request->email,
                'phone' => $request->phone,
                'delivery_pin' => strtoupper(str_random(5)),
                'password' => \Hash::make($request->password),
            ]);

            if ($request->has('role')) {
                $user->assignRole($request->role);
            }

            if ($user->hasRole('Delivery Guy')) {

                $deliveryGuyDetails = new DeliveryGuyDetail();
                $deliveryGuyDetails->name = $request->delivery_name;
                $deliveryGuyDetails->age = $request->delivery_age;
                if ($request->hasFile('delivery_photo')) {
                    $photo = $request->file('delivery_photo');
                    $filename = time() . str_random(10) . '.' . strtolower($photo->getClientOriginalExtension());
                    Image::make($photo)->resize(250, 250)->save(base_path('/assets/img/delivery/' . $filename));
                    $deliveryGuyDetails->photo = $filename;
                }
                $deliveryGuyDetails->description = $request->delivery_description;
                $deliveryGuyDetails->vehicle_number = $request->delivery_vehicle_number;
                if ($request->delivery_commission_rate != null) {
                    $deliveryGuyDetails->commission_rate = $request->delivery_commission_rate;
                }
                $deliveryGuyDetails->save();
                $user->delivery_guy_detail_id = $deliveryGuyDetails->id;
                $user->save();

            }

            return redirect()->back()->with(['success' => 'User Created']);
        } catch (\Illuminate\Database\QueryException $qe) {
            return redirect()->back()->with(['message' => $qe->getMessage()]);
        } catch (Exception $e) {
            return redirect()->back()->with(['message' => $e->getMessage()]);
        } catch (\Throwable $th) {
            return redirect()->back()->with(['message' => $th]);
        }
    }

    /**
     * @param Request $request
     */
    public function postSearchUsers(Request $request)
    {
        $query = $request['query'];

        $users = User::where('name', 'LIKE', '%' . $query . '%')
            ->orWhere('email', 'LIKE', '%' . $query . '%')
            ->with('roles', 'wallet')
            ->paginate(20);

        $roles = Role::all();

        $count = $users->total();

        return view('admin.users', array(
            'users' => $users,
            'query' => $query,
            'count' => $count,
            'roles' => $roles,
        ));
    }

    /**
     * @param $id
     */
    public function getEditUser($id)
    {
        $user = User::where('id', $id)->first();
        $roles = Role::get();
        // dd($user->delivery_guy_detail);
        return view('admin.editUser', array(
            'user' => $user,
            'roles' => $roles,
        ));
    }

    /**
     * @param Request $request
     */
    public function updateUser(Request $request)
    {
        // dd($request->all());
        $user = User::where('id', $request->id)->first();
        try {
            $user->name = $request->name;
            $user->email = $request->email;
            $user->phone = $request->phone;
            if ($request->has('password') && $request->password != null) {
                $user->password = \Hash::make($request->password);
            }
            if ($request->roles != null) {
                $user->syncRoles($request->roles);
            }
            $user->save();

            if ($user->hasRole('Delivery Guy')) {

                if ($user->delivery_guy_detail == null) {

                    $deliveryGuyDetails = new DeliveryGuyDetail();
                    $deliveryGuyDetails->name = $request->delivery_name;
                    $deliveryGuyDetails->age = $request->delivery_age;
                    if ($request->hasFile('delivery_photo')) {
                        $photo = $request->file('delivery_photo');
                        $filename = time() . str_random(10) . '.' . strtolower($photo->getClientOriginalExtension());
                        Image::make($photo)->resize(250, 250)->save(base_path('/assets/img/delivery/' . $filename));
                        $deliveryGuyDetails->photo = $filename;
                    }
                    $deliveryGuyDetails->description = $request->delivery_description;
                    $deliveryGuyDetails->vehicle_number = $request->delivery_vehicle_number;

                    if ($request->delivery_commission_rate != null) {
                        $deliveryGuyDetails->commission_rate = $request->delivery_commission_rate;
                    }

                    if ($request->is_notifiable == 'true') {
                        $deliveryGuyDetails->is_notifiable = true;
                    } else {
                        $deliveryGuyDetails->is_notifiable = false;
                    }

                    if ($request->max_accept_delivery_limit != null) {
                        $deliveryGuyDetails->max_accept_delivery_limit = $request->max_accept_delivery_limit;
                    }

                    $deliveryGuyDetails->save();
                    $user->delivery_guy_detail_id = $deliveryGuyDetails->id;
                    $user->save();
                } else {
                    $user->delivery_guy_detail->name = $request->delivery_name;
                    $user->delivery_guy_detail->age = $request->delivery_age;
                    if ($request->hasFile('delivery_photo')) {
                        $photo = $request->file('delivery_photo');
                        $filename = time() . str_random(10) . '.' . strtolower($photo->getClientOriginalExtension());
                        Image::make($photo)->resize(250, 250)->save(base_path('/assets/img/delivery/' . $filename));
                        $user->delivery_guy_detail->photo = $filename;
                    }
                    $user->delivery_guy_detail->description = $request->delivery_description;
                    $user->delivery_guy_detail->vehicle_number = $request->delivery_vehicle_number;
                    if ($request->delivery_commission_rate != null) {
                        $user->delivery_guy_detail->commission_rate = $request->delivery_commission_rate;
                    }
                    if ($request->is_notifiable == 'true') {
                        $user->delivery_guy_detail->is_notifiable = true;
                    } else {
                        $user->delivery_guy_detail->is_notifiable = false;
                    }

                    if ($request->max_accept_delivery_limit != null) {
                        $user->delivery_guy_detail->max_accept_delivery_limit = $request->max_accept_delivery_limit;
                    }

                    $user->delivery_guy_detail->save();
                }
            }

            return redirect()->back()->with(['success' => 'User Updated']);
        } catch (\Illuminate\Database\QueryException $qe) {
            return redirect()->back()->with(['message' => $qe->getMessage()]);
        } catch (Exception $e) {
            return redirect()->back()->with(['message' => $e->getMessage()]);
        } catch (\Throwable $th) {
            return redirect()->back()->with(['message' => $th]);
        }
    }

    /**
     * @param $id
     */
    public function banUser($id)
    {
        $user = User::where('id', $id)->firstOrFail();
        $user->toggleActive()->save();
        return redirect()->back()->with(['success' => 'Operation Successful']);
    }

    public function manageDeliveryGuys()
    {
        $users = User::role('Delivery Guy')->orderBy('id', 'DESC')->with('roles')->paginate(20);
        $count = $users->total();
        return view('admin.manageDeliveryGuys', array(
            'users' => $users,
            'count' => $count,
        ));
    }

    /**
     * @param $id
     */
    public function getManageDeliveryGuysRestaurants($id)
    {
        $user = User::where('id', $id)->first();
        if ($user->hasRole('Delivery Guy')) {
            $userRestaurants = $user->restaurants;
            $userRestaurantsIds = $user->restaurants->pluck('id')->toArray();

            $allRestaurants = Restaurant::get();

            return view('admin.manageDeliveryGuysRestaurants', array(
                'user' => $user,
                'userRestaurants' => $userRestaurants,
                'allRestaurants' => $allRestaurants,
                'userRestaurantsIds' => $userRestaurantsIds,
            ));
        }
    }

    /**
     * @param Request $request
     */
    public function updateDeliveryGuysRestaurants(Request $request)
    {
        $user = User::where('id', $request->id)->first();
        $user->restaurants()->sync($request->user_restaurants);
        $user->save();
        return redirect()->back()->with(['success' => 'Delivery Guy Updated']);
    }

    public function manageRestaurantOwners()
    {
        $users = User::role('Store Owner')->orderBy('id', 'DESC')->with('roles')->paginate(20);
        $count = $users->total();

        return view('admin.manageRestaurantOwners', array(
            'users' => $users,
            'count' => $count,
        ));
    }

    /**
     * @param $id
     */
    public function getManageRestaurantOwnersRestaurants($id)
    {
        $user = User::where('id', $id)->first();
        if ($user->hasRole('Store Owner')) {
            $userRestaurants = $user->restaurants;
            $userRestaurantsIds = $user->restaurants->pluck('id')->toArray();
            $allRestaurants = Restaurant::get();

            return view('admin.manageRestaurantOwnersRestaurants', array(
                'user' => $user,
                'userRestaurants' => $userRestaurants,
                'allRestaurants' => $allRestaurants,
                'userRestaurantsIds' => $userRestaurantsIds,
            ));
        }
    }

    /**
     * @param Request $request
     */
    public function updateManageRestaurantOwnersRestaurants(Request $request)
    {
        $user = User::where('id', $request->id)->first();
        $user->restaurants()->sync($request->user_restaurants);
        $user->save();
        return redirect()->back()->with(['success' => 'Store Owner Updated']);
    }

    public function orders()
    {
        $orders = Order::orderBy('id', 'DESC')->with('accept_delivery.user', 'restaurant')->paginate(20);
        $count = $orders->total();
        return view('admin.orders', array(
            'orders' => $orders,
            'count' => $count,
        ));
    }

    /**
     * @param Request $request
     */
    public function postSearchOrders(Request $request)
    {
        $query = $request['query'];

        $orders = Order::where('unique_order_id', 'LIKE', '%' . $query . '%')->with('accept_delivery.user', 'restaurant')->paginate(20);

        $count = $orders->total();

        return view('admin.orders', array(
            'orders' => $orders,
            'count' => $count,
        ));
    }

    /**
     * @param $order_id
     */
    public function viewOrder($order_id)
    {
        $order = Order::where('unique_order_id', $order_id)->with('orderitems.order_item_addons')->first();
        $users = User::role('Delivery Guy')->get();
        if ($order) {
            return view('admin.viewOrder', array(
                'order' => $order,
                'users' => $users,
            ));
        } else {
            return redirect()->route('admin.orders');
        }
    }

    public function sliders()
    {
        $sliders = PromoSlider::orderBy('id', 'DESC')->with('slides')->get();
        $count = count($sliders);
        return view('admin.sliders', array(
            'sliders' => $sliders,
            'count' => $count,
        ));
    }

    /**
     * @param $id
     */
    public function getEditSlider($id)
    {
        $restaurants = Restaurant::get();
        $slider = PromoSlider::where('id', $id)->first();

        if ($slider) {
            return view('admin.editSlider', array(
                'restaurants' => $restaurants,
                'slider' => $slider,
                'slides' => $slider->slides,
            ));
        } else {
            return redirect()->route('admin.sliders');
        }
    }

    /**
     * @param Request $request
     */
    public function updateSlider(Request $request)
    {
        $slider = PromoSlider::where('id', $request->id)->first();
        $slider->name = $request->name;
        $slider->position_id = $request->position_id;
        $slider->size = $request->size;
        $slider->save();

        return redirect()->back()->with(['success' => 'Slider Updated']);

    }
    /**
     * @param Request $request
     */
    public function createSlider(Request $request)
    {
        $sliderCount = PromoSlider::where('is_active', 1)->count();

        if ($sliderCount >= 2) {
            return redirect()->back()->with(['message' => 'Only two sliders can be created. Disbale or delete some Sliders to create more.']);
        }

        $slider = new PromoSlider();
        $slider->name = $request->name;
        $slider->location_id = '0';
        $slider->position_id = $request->position_id;
        $slider->size = $request->size;
        $slider->save();
        return redirect()->back()->with(['success' => 'New Slider Created']);
    }

    /**
     * @param $id
     */
    public function disableSlider($id)
    {
        $slider = PromoSlider::where('id', $id)->first();
        if ($slider) {
            $slider->toggleActive()->save();
            return redirect()->back()->with(['success' => 'Operation Successful']);
        } else {
            return redirect()->route('admin.sliders');
        }
    }

    /**
     * @param $id
     */
    public function deleteSlider($id)
    {
        $slider = PromoSlider::where('id', $id)->first();
        if ($slider) {
            $slides = $slider->slides;
            foreach ($slides as $slide) {
                $slide->delete();
            }
            $slider->delete();
            return redirect()->back()->with(['success' => 'Operation Successful']);
        } else {
            return redirect()->route('admin.sliders');
        }
    }

    /**
     * @param Request $request
     */
    public function saveSlide(Request $request)
    {
        $url = url('/');
        $url = substr($url, 0, strrpos($url, '/')); //this will give url without "/public"

        $slide = new Slide();
        $slide->promo_slider_id = $request->promo_slider_id;
        $slide->name = $request->name;
        $slide->url = $request->url;

        $image = $request->file('image');
        $rand_name = time() . str_random(10);
        $filename = $rand_name . '.' . $image->getClientOriginalExtension();

        Image::make($image)
            ->resize(384, 384)
            ->save(base_path('assets/img/slider/' . $filename));
        $slide->image = '/assets/img/slider/' . $filename;

        if ($request->customUrl != null) {
            $slide->url = $request->customUrl;
        }

        $slide->save();

        return redirect()->back()->with(['success' => 'New Slide Created']);
    }

    /**
     * @param $id
     */
    public function editSlide($id)
    {
        $slide = Slide::where('id', $id)->with('promo_slider')->first();
        $restaurants = Restaurant::get();
        if ($slide) {
            return view('admin.editSlide', array(
                'slide' => $slide,
                'restaurants' => $restaurants,
            ));
        } else {
            return redirect()->route('admin.sliders')->with(['message' => 'Slide Not Found']);
        }
    }

    /**
     * @param Request $request
     */
    public function updateSlide(Request $request)
    {
        $slide = Slide::where('id', $request->id)->first();
        if ($slide) {
            $slide->name = $request->name;
            if ($request->url != null) {
                $slide->url = $request->url;
            }
            if ($request->hasFile('image')) {

                $image = $request->file('image');
                $rand_name = time() . str_random(10);
                $filename = $rand_name . '.' . $image->getClientOriginalExtension();
                Image::make($image)
                    ->resize(384, 384)
                    ->save(base_path('assets/img/slider/' . $filename));
                $slide->image = '/assets/img/slider/' . $filename;
            }
            if ($request->customUrl != null) {
                $slide->url = $request->customUrl;
            }
            $slide->save();
            return redirect()->back()->with(['success' => 'Slide Updated']);
        } else {
            return redirect()->route('admin.sliders')->with(['message' => 'Slide Not Found']);
        }
    }

    /**
     * @param Request $request
     */
    public function updateSlidePosition(Request $request)
    {
        Slide::setNewOrder($request->newOrder);
        Artisan::call('cache:clear');
        return response()->json(['success' => true]);
    }

    /**
     * @param $id
     */
    public function deleteSlide($id)
    {
        $slide = Slide::where('id', $id)->first();
        if ($slide) {
            $slide->delete();
            return redirect()->back()->with(['success' => 'Deleted']);
        } else {
            return redirect()->route('admin.sliders');
        }
    }

    /**
     * @param $id
     */
    public function disableSlide($id)
    {
        $slide = Slide::where('id', $id)->first();
        if ($slide) {
            $slide->toggleActive()->save();
            return redirect()->back()->with(['success' => 'Operation Successful']);
        } else {
            return redirect()->route('admin.sliders');
        }
    }

    public function restaurants()
    {
        $restaurants = Restaurant::where('is_accepted', '1')->with('users.roles')->ordered()->paginate(20);
        $count = $restaurants->total();

        return view('admin.restaurants', array(
            'restaurants' => $restaurants,
            'count' => $count,
        ));
    }

    public function sortStores()
    {
        $restaurants = Restaurant::where('is_accepted', '1')->with('users.roles')->ordered()->get();
        $count = $restaurants->count();
        return view('admin.sortStores', array(
            'restaurants' => $restaurants,
            'count' => $count,
        ));
    }

    /**
     * @param Request $request
     */
    public function updateStorePosition(Request $request)
    {
        Restaurant::setNewOrder($request->newOrder);
        Artisan::call('cache:clear');
        return response()->json(['success' => true]);
    }

    public function pendingAcceptance()
    {
        $count = Restaurant::count();
        $restaurants = Restaurant::orderBy('id', 'DESC')->where('is_accepted', '0')->with('users.roles')->paginate(10000);
        $count = count($restaurants);

        return view('admin.restaurants', array(
            'restaurants' => $restaurants,
            'count' => $count,
        ));
    }

    /**
     * @param $id
     */
    public function acceptRestaurant($id)
    {
        $restaurant = Restaurant::where('id', $id)->first();
        if ($restaurant) {
            $restaurant->toggleAcceptance()->save();
            return redirect()->back()->with(['success' => 'Operation Successful']);
        } else {
            return redirect()->route('admin.restaurants');
        }
    }

    /**
     * @param Request $request
     */
    public function searchRestaurants(Request $request)
    {
        $query = $request['query'];

        $restaurants = Restaurant::where('name', 'LIKE', '%' . $query . '%')
            ->orWhere('sku', 'LIKE', '%' . $query . '%')->with('users.roles')->paginate(20);

        $count = $restaurants->total();

        return view('admin.restaurants', array(
            'restaurants' => $restaurants,
            'query' => $query,
            'count' => $count,
        ));
    }

    /**
     * @param $id
     */
    public function disableRestaurant($id)
    {
        $restaurant = Restaurant::where('id', $id)->first();
        if ($restaurant) {
            $restaurant->is_schedulable = false;
            $restaurant->toggleActive();
            $restaurant->save();
            return redirect()->back()->with(['success' => 'Operation Successful']);
        } else {
            return redirect()->route('admin.restaurants');
        }
    }

    /**
     * @param $id
     */
    public function deleteRestaurant($id)
    {
        $restaurant = Restaurant::where('id', $id)->first();
        if ($restaurant) {
            $items = $restaurant->items;
            foreach ($items as $item) {
                $item->delete();
            }
            $restaurant->delete();
            return redirect()->route('admin.restaurants');
        } else {
            return redirect()->route('admin.restaurants');
        }
    }

    /**
     * @param Request $request
     */
    public function saveNewRestaurant(Request $request)
    {
        $restaurant = new Restaurant();

        $restaurant->name = $request->name;
        $restaurant->description = $request->description;

        $image = $request->file('image');
        $rand_name = time() . str_random(10);
        $filename = $rand_name . '.jpg';
        Image::make($image)
            ->resize(160, 117)
            ->save(base_path('assets/img/restaurants/' . $filename), config('settings.uploadImageQuality '), 'jpg');
        $restaurant->image = '/assets/img/restaurants/' . $filename;

        $restaurant->rating = $request->rating;
        $restaurant->delivery_time = $request->delivery_time;
        $restaurant->price_range = $request->price_range;

        if ($request->is_pureveg == 'true') {
            $restaurant->is_pureveg = true;
        } else {
            $restaurant->is_pureveg = false;
        }

        if ($request->is_featured == 'true') {
            $restaurant->is_featured = true;
        } else {
            $restaurant->is_featured = false;
        }

        $restaurant->slug = str_slug($request->name) . '-' . str_random(15);
        $restaurant->certificate = $request->certificate;

        $restaurant->address = $request->address;
        $restaurant->pincode = $request->pincode;
        $restaurant->landmark = $request->landmark;
        $restaurant->latitude = $request->latitude;
        $restaurant->longitude = $request->longitude;

        $restaurant->restaurant_charges = $request->restaurant_charges;
        $restaurant->delivery_charges = $request->delivery_charges;
        $restaurant->commission_rate = $request->commission_rate;

        if ($request->has('delivery_type')) {
            $restaurant->delivery_type = $request->delivery_type;
        }

        if ($request->delivery_charge_type == 'FIXED') {
            $restaurant->delivery_charge_type = 'FIXED';
            $restaurant->delivery_charges = $request->delivery_charges;
        }
        if ($request->delivery_charge_type == 'DYNAMIC') {
            $restaurant->delivery_charge_type = 'DYNAMIC';
            $restaurant->base_delivery_charge = $request->base_delivery_charge;
            $restaurant->base_delivery_distance = $request->base_delivery_distance;
            $restaurant->extra_delivery_charge = $request->extra_delivery_charge;
            $restaurant->extra_delivery_distance = $request->extra_delivery_distance;
        }
        if ($request->delivery_radius != null) {
            $restaurant->delivery_radius = $request->delivery_radius;
        }

        $restaurant->sku = time() . str_random(10);
        $restaurant->is_active = 0;
        $restaurant->is_accepted = 1;

        $restaurant->min_order_price = $request->min_order_price;

        try {
            $restaurant->save();
            return redirect()->back()->with(['success' => 'Restaurant Saved']);
        } catch (\Illuminate\Database\QueryException $qe) {
            return redirect()->back()->with(['message' => $qe->getMessage()]);
        } catch (Exception $e) {
            return redirect()->back()->with(['message' => $e->getMessage()]);
        } catch (\Throwable $th) {
            return redirect()->back()->with(['message' => $th]);
        }
    }

    /**
     * @param $id
     */
    public function getRestaurantItems($id)
    {
        $items = Item::where('restaurant_id', $id)->paginate(20);

        $count = Item::where('restaurant_id', $id)->count();

        $restaurants = Restaurant::all();

        $itemCategories = ItemCategory::where('is_enabled', '1')->get();

        $addonCategories = AddonCategory::all();

        return view('admin.items', array(
            'items' => $items,
            'count' => $count,
            'restaurants' => $restaurants,
            'itemCategories' => $itemCategories,
            'addonCategories' => $addonCategories,
        ));

    }
    /**
     * @param $id
     */
    public function getEditRestaurant($id)
    {
        $restaurant = Restaurant::where('id', $id)->first();
        $restaurantCategories = RestaurantCategory::where('is_active', '1')->get();

        return view('admin.editRestaurant', array(
            'restaurant' => $restaurant,
            'restaurantCategories' => $restaurantCategories,
            'schedule_data' => json_decode($restaurant->schedule_data),
        ));
    }

    /**
     * @param Request $request
     */
    public function updateRestaurant(Request $request)
    {
        $restaurant = Restaurant::where('id', $request->id)->first();

        if ($restaurant) {
            $restaurant->name = $request->name;
            $restaurant->description = $request->description;

            if ($request->image == null) {
                $restaurant->image = $request->old_image;
            } else {

                $image = $request->file('image');
                $rand_name = time() . str_random(10);
                $filename = $rand_name . '.jpg';
                Image::make($image)
                    ->resize(160, 117)
                    ->save(base_path('assets/img/restaurants/' . $filename), config('settings.uploadImageQuality '), 'jpg');
                $restaurant->image = '/assets/img/restaurants/' . $filename;

            }

            $restaurant->rating = $request->rating;
            $restaurant->delivery_time = $request->delivery_time;
            $restaurant->price_range = $request->price_range;

            if ($request->is_pureveg == 'true') {
                $restaurant->is_pureveg = true;
            } else {
                $restaurant->is_pureveg = false;
            }

            if ($request->is_featured == 'true') {
                $restaurant->is_featured = true;
            } else {
                $restaurant->is_featured = false;
            }

            $restaurant->certificate = $request->certificate;

            $restaurant->address = $request->address;
            $restaurant->pincode = $request->pincode;
            $restaurant->landmark = $request->landmark;
            $restaurant->latitude = $request->latitude;
            $restaurant->longitude = $request->longitude;

            $restaurant->restaurant_charges = $request->restaurant_charges;
            $restaurant->delivery_charges = $request->delivery_charges;
            $restaurant->commission_rate = $request->commission_rate;

            if ($request->has('delivery_type')) {
                $restaurant->delivery_type = $request->delivery_type;
            }

            if ($request->delivery_charge_type == 'FIXED') {
                $restaurant->delivery_charge_type = 'FIXED';
                $restaurant->delivery_charges = $request->delivery_charges;
            }
            if ($request->delivery_charge_type == 'DYNAMIC') {
                $restaurant->delivery_charge_type = 'DYNAMIC';
                $restaurant->base_delivery_charge = $request->base_delivery_charge;
                $restaurant->base_delivery_distance = $request->base_delivery_distance;
                $restaurant->extra_delivery_charge = $request->extra_delivery_charge;
                $restaurant->extra_delivery_distance = $request->extra_delivery_distance;
            }
            if ($request->delivery_radius != null) {
                $restaurant->delivery_radius = $request->delivery_radius;
            }

            $restaurant->min_order_price = $request->min_order_price;

            if ($request->is_schedulable == 'true') {
                $restaurant->is_schedulable = true;
            } else {
                $restaurant->is_schedulable = false;
            }

            if ($request->is_notifiable == 'true') {
                $restaurant->is_notifiable = true;
            } else {
                $restaurant->is_notifiable = false;
            }

            if ($request->auto_acceptable == 'true') {
                $restaurant->auto_acceptable = true;
            } else {
                $restaurant->auto_acceptable = false;
            }

            try {
                if (isset($request->restaurant_category_restaurant)) {
                    $restaurant->restaurant_categories()->sync($request->restaurant_category_restaurant);
                }
                $restaurant->save();
                return redirect()->back()->with(['success' => 'Restaurant Updated']);
            } catch (\Illuminate\Database\QueryException $qe) {
                return redirect()->back()->with(['message' => $qe->getMessage()]);
            } catch (Exception $e) {
                return redirect()->back()->with(['message' => $e->getMessage()]);
            } catch (\Throwable $th) {
                return redirect()->back()->with(['message' => $th]);
            }
        }
    }

    /**
     * @param Request $request
     */
    public function updateSlug(Request $request)
    {
        $restaurant = Restaurant::where('id', $request->id)->firstOrFail();

        try {

            $restaurant->slug = Str::slug($request->store_url);
            $restaurant->save();
            return redirect()->back()->with(['success' => 'URL Updated']);

        } catch (\Illuminate\Database\QueryException $qe) {
            $errorCode = $qe->errorInfo[1];
            if ($errorCode == 1062) {
                return redirect()->back()->with(['message' => 'URL should be unique, it should not match with other store URLs']);
            }
            return redirect()->back()->with(['message' => $qe->getMessage()]);
        } catch (Exception $e) {
            return redirect()->back()->with(['message' => $e->getMessage()]);
        } catch (\Throwable $th) {
            return redirect()->back()->with(['message' => $th]);
        }

    }

    public function items()
    {
        $items = Item::orderBy('id', 'DESC')->with('item_category', 'restaurant')->paginate(20);
        $count = $items->total();

        $restaurants = Restaurant::all();
        $itemCategories = ItemCategory::where('is_enabled', '1')->get();
        $addonCategories = AddonCategory::all();

        return view('admin.items', array(
            'items' => $items,
            'count' => $count,
            'restaurants' => $restaurants,
            'itemCategories' => $itemCategories,
            'addonCategories' => $addonCategories,
        ));
    }

    /**
     * @param Request $request
     */
    public function searchItems(Request $request)
    {
        $query = $request['query'];

        $items = Item::where('name', 'LIKE', '%' . $query . '%')->with('item_category', 'restaurant')->paginate(20);
        $count = $items->total();

        $restaurants = Restaurant::get();
        $itemCategories = ItemCategory::where('is_enabled', '1')->get();
        $addonCategories = AddonCategory::all();

        return view('admin.items', array(
            'items' => $items,
            'count' => $count,
            'restaurants' => $restaurants,
            'query' => $query,
            'itemCategories' => $itemCategories,
            'addonCategories' => $addonCategories,
        ));
    }

    /**
     * @param Request $request
     */
    public function saveNewItem(Request $request)
    {
        // dd($request->all());

        $item = new Item();

        $item->name = $request->name;
        $item->price = $request->price;
        $item->old_price = $request->old_price == null ? 0 : $request->old_price;
        $item->restaurant_id = $request->restaurant_id;
        $item->item_category_id = $request->item_category_id;

        $image = $request->file('image');
        $rand_name = time() . str_random(10);
        $filename = $rand_name . '.jpg';
        Image::make($image)
            ->resize(486, 355)
            ->save(base_path('assets/img/items/' . $filename), config('settings.uploadImageQuality '), 'jpg');
        $item->image = '/assets/img/items/' . $filename;

        if ($request->is_recommended == 'true') {
            $item->is_recommended = true;
        } else {
            $item->is_recommended = false;
        }

        if ($request->is_popular == 'true') {
            $item->is_popular = true;
        } else {
            $item->is_popular = false;
        }

        if ($request->is_new == 'true') {
            $item->is_new = true;
        } else {
            $item->is_new = false;
        }

        if ($request->is_veg == 'true') {
            $item->is_veg = true;
        } else {
            $item->is_veg = false;
        }

        $item->desc = $request->desc;

        try {
            $item->save();
            if (isset($request->addon_category_item)) {
                $item->addon_categories()->sync($request->addon_category_item);
            }
            return redirect()->back()->with(['success' => 'Item Saved']);
        } catch (\Illuminate\Database\QueryException $qe) {
            return redirect()->back()->with(['message' => $qe->getMessage()]);
        } catch (Exception $e) {
            return redirect()->back()->with(['message' => $e->getMessage()]);
        } catch (\Throwable $th) {
            return redirect()->back()->with(['message' => $th]);
        }

    }

    /**
     * @param $id
     */
    public function getEditItem($id)
    {
        $item = Item::where('id', $id)->first();
        $restaurants = Restaurant::get();
        $itemCategories = ItemCategory::where('is_enabled', '1')->get();
        $addonCategories = AddonCategory::all();

        return view('admin.editItem', array(
            'item' => $item,
            'restaurants' => $restaurants,
            'itemCategories' => $itemCategories,
            'addonCategories' => $addonCategories,
        ));
    }

    /**
     * @param $id
     */
    public function disableItem($id)
    {
        $item = Item::where('id', $id)->first();
        if ($item) {
            $item->toggleActive()->save();
            return redirect()->back()->with(['success' => 'Operation Successful']);
        } else {
            return redirect()->route('admin.items');
        }
    }

    /**
     * @param Request $request
     */
    public function updateItem(Request $request)
    {
        $item = Item::where('id', $request->id)->first();

        if ($item) {

            $item->name = $request->name;
            $item->restaurant_id = $request->restaurant_id;
            $item->item_category_id = $request->item_category_id;

            if ($request->image == null) {
                $item->image = $request->old_image;
            } else {
                $image = $request->file('image');
                $rand_name = time() . str_random(10);
                $filename = $rand_name . '.jpg';
                Image::make($image)
                    ->resize(486, 355)
                    ->save(base_path('assets/img/items/' . $filename), config('settings.uploadImageQuality '), 'jpg');
                $item->image = '/assets/img/items/' . $filename;
            }

            $item->price = $request->price;
            $item->old_price = $request->old_price == null ? 0 : $request->old_price;

            if ($request->is_recommended == 'true') {
                $item->is_recommended = true;
            } else {
                $item->is_recommended = false;
            }

            if ($request->is_popular == 'true') {
                $item->is_popular = true;
            } else {
                $item->is_popular = false;
            }

            if ($request->is_new == 'true') {
                $item->is_new = true;
            } else {
                $item->is_new = false;
            }

            if ($request->is_veg == 'true') {
                $item->is_veg = true;
            } else {
                $item->is_veg = false;
            }

            $item->desc = $request->desc;

            try {
                $item->save();
                if (isset($request->addon_category_item)) {
                    $item->addon_categories()->sync($request->addon_category_item);
                }
                if ($request->remove_all_addons == '1') {
                    $item->addon_categories()->sync($request->addon_category_item);
                }
                return redirect()->back()->with(['success' => 'Item Updated']);

            } catch (\Illuminate\Database\QueryException $qe) {
                return redirect()->back()->with(['message' => $qe->getMessage()]);
            } catch (Exception $e) {
                return redirect()->back()->with(['message' => $e->getMessage()]);
            } catch (\Throwable $th) {
                return redirect()->back()->with(['message' => $th]);
            }
        }
    }

    public function addonCategories()
    {
        $addonCategories = AddonCategory::orderBy('id', 'DESC')->paginate(20);
        $addonCategories->loadCount('addons');

        $count = $addonCategories->total();

        return view('admin.addonCategories', array(
            'addonCategories' => $addonCategories,
            'count' => $count,
        ));
    }

    /**
     * @param Request $request
     */
    public function searchAddonCategories(Request $request)
    {
        $query = $request['query'];

        $addonCategories = AddonCategory::where('name', 'LIKE', '%' . $query . '%')->paginate(20);
        $addonCategories->loadCount('addons');

        $count = $addonCategories->total();

        return view('admin.addonCategories', array(
            'addonCategories' => $addonCategories,
            'count' => $count,
        ));
    }

    /**
     * @param Request $request
     */
    public function saveNewAddonCategory(Request $request)
    {
        $addonCategory = new AddonCategory();

        $addonCategory->name = $request->name;
        $addonCategory->type = $request->type;
        $addonCategory->user_id = Auth::user()->id;

        try {
            $addonCategory->save();
            return redirect()->back()->with(['success' => 'Addon Category Saved']);
        } catch (\Illuminate\Database\QueryException $qe) {
            return redirect()->back()->with(['message' => $qe->getMessage()]);
        } catch (Exception $e) {
            return redirect()->back()->with(['message' => $e->getMessage()]);
        } catch (\Throwable $th) {
            return redirect()->back()->with(['message' => $th]);
        }
    }

    /**
     * @param $id
     */
    public function getEditAddonCategory($id)
    {
        $addonCategory = AddonCategory::where('id', $id)->first();
        return view('admin.editAddonCategory', array(
            'addonCategory' => $addonCategory,
        ));
    }

    /**
     * @param Request $request
     */
    public function updateAddonCategory(Request $request)
    {
        $addonCategory = AddonCategory::where('id', $request->id)->first();

        if ($addonCategory) {

            $addonCategory->name = $request->name;
            $addonCategory->type = $request->type;

            try {
                $addonCategory->save();
                return redirect()->back()->with(['success' => 'Addon Category Updated']);
            } catch (\Illuminate\Database\QueryException $qe) {
                return redirect()->back()->with(['message' => $qe->getMessage()]);
            } catch (Exception $e) {
                return redirect()->back()->with(['message' => $e->getMessage()]);
            } catch (\Throwable $th) {
                return redirect()->back()->with(['message' => $th]);
            }
        }
    }

    public function addons()
    {

        $addons = Addon::orderBy('id', 'DESC')->with('addon_category')->paginate(20);
        $count = $addons->total();

        $addonCategories = AddonCategory::all();

        return view('admin.addons', array(
            'addons' => $addons,
            'count' => $count,
            'addonCategories' => $addonCategories,
        ));
    }

    /**
     * @param Request $request
     */
    public function searchAddons(Request $request)
    {
        $query = $request['query'];

        $addons = Addon::where('name', 'LIKE', '%' . $query . '%')->with('addon_category')->paginate(20);

        $count = $addons->total();

        $addonCategories = AddonCategory::all();

        return view('admin.addons', array(
            'addons' => $addons,
            'count' => $count,
            'addonCategories' => $addonCategories,
        ));
    }

    /**
     * @param Request $request
     */
    public function saveNewAddon(Request $request)
    {
        // dd($request->all());
        $addon = new Addon();

        $addon->name = $request->name;
        $addon->price = $request->price;
        $addon->user_id = Auth::user()->id;
        $addon->addon_category_id = $request->addon_category_id;

        try {
            $addon->save();
            return redirect()->back()->with(['success' => 'Addon Saved']);
        } catch (\Illuminate\Database\QueryException $qe) {
            return redirect()->back()->with(['message' => $qe->getMessage()]);
        } catch (Exception $e) {
            return redirect()->back()->with(['message' => $e->getMessage()]);
        } catch (\Throwable $th) {
            return redirect()->back()->with(['message' => $th]);
        }

    }

    /**
     * @param $id
     */
    public function getEditAddon($id)
    {
        $addon = Addon::where('id', $id)->first();
        $addonCategories = AddonCategory::all();
        return view('admin.editAddon', array(
            'addon' => $addon,
            'addonCategories' => $addonCategories,
        ));
    }

    /**
     * @param Request $request
     */
    public function updateAddon(Request $request)
    {
        $addon = Addon::where('id', $request->id)->first();

        if ($addon) {

            $addon->name = $request->name;
            $addon->price = $request->price;
            $addon->addon_category_id = $request->addon_category_id;

            try {
                $addon->save();
                return redirect()->back()->with(['success' => 'Addon Updated']);
            } catch (\Illuminate\Database\QueryException $qe) {
                return redirect()->back()->with(['message' => $qe->getMessage()]);
            } catch (Exception $e) {
                return redirect()->back()->with(['message' => $e->getMessage()]);
            } catch (\Throwable $th) {
                return redirect()->back()->with(['message' => $th]);
            }
        }
    }

    /**
     * @param $id
     */
    public function disableAddon($id)
    {
        $addon = Addon::where('id', $id)->firstOrFail();
        if ($addon) {
            $addon->toggleActive()->save();
            return redirect()->back()->with(['success' => 'Operation Successful']);
        } else {
            return redirect()->back()->with(['message' => 'Something Went Wrong']);
        }
    }

    /**
     * @param $id
     */
    public function addonsOfAddonCategory($id)
    {
        $addons = Addon::orderBy('id', 'DESC')->where('addon_category_id', $id)->with('addon_category')->paginate(20);
        $count = $addons->total();
        $addonCategories = AddonCategory::all();

        return view('admin.addons', array(
            'addons' => $addons,
            'count' => $count,
            'addonCategories' => $addonCategories,
        ));
    }

    public function itemcategories()
    {
        $itemCategories = ItemCategory::orderBy('id', 'DESC')->with('user')->get();
        $itemCategories->loadCount('items');

        $count = count($itemCategories);

        return view('admin.itemcategories', array(
            'itemCategories' => $itemCategories,
            'count' => $count,
        ));
    }

    /**
     * @param Request $request
     */
    public function createItemCategory(Request $request)
    {
        $itemCategory = new ItemCategory();

        $itemCategory->name = $request->name;
        $itemCategory->user_id = Auth::user()->id;

        try {
            $itemCategory->save();
            return redirect()->back()->with(['success' => 'Category Created']);
        } catch (\Illuminate\Database\QueryException $qe) {
            return redirect()->back()->with(['message' => $qe->getMessage()]);
        } catch (Exception $e) {
            return redirect()->back()->with(['message' => $e->getMessage()]);
        } catch (\Throwable $th) {
            return redirect()->back()->with(['message' => $th]);
        }
    }

    /**
     * @param $id
     */
    public function disableCategory($id)
    {
        $itemCategory = ItemCategory::where('id', $id)->first();
        if ($itemCategory) {
            $itemCategory->toggleEnable()->save();
            return redirect()->back()->with(['success' => 'Operation Successful']);
        } else {
            return redirect()->route('admin.itemcategories');
        }
    }

    /**
     * @param Request $request
     */
    public function updateItemCategory(Request $request)
    {
        $itemCategory = ItemCategory::where('id', $request->id)->firstOrFail();
        $itemCategory->name = $request->name;
        $itemCategory->save();
        return redirect()->back()->with(['success' => 'Operation Successful']);
    }

    public function pages()
    {
        $pages = Page::all();
        return view('admin.pages', array(
            'pages' => $pages,
        ));
    }

    /**
     * @param Request $request
     */
    public function saveNewPage(Request $request)
    {
        $page = new Page();
        $page->name = $request->name;
        $page->slug = Str::slug($request->slug, '-');
        $page->body = $request->body;

        try {
            $page->save();
            return redirect()->back()->with(['success' => 'New Page Created']);
        } catch (\Illuminate\Database\QueryException $qe) {
            return redirect()->back()->with(['message' => $qe->getMessage()]);
        } catch (Exception $e) {
            return redirect()->back()->with(['message' => $e->getMessage()]);
        } catch (\Throwable $th) {
            return redirect()->back()->with(['message' => $th]);
        }
    }

    /**
     * @param $id
     */
    public function getEditPage($id)
    {
        $page = Page::where('id', $id)->first();

        if ($page) {
            return view('admin.editPage', array(
                'page' => $page,
            ));
        } else {
            return redirect()->route('admin.pages');
        }
    }

    /**
     * @param Request $request
     */
    public function updatePage(Request $request)
    {
        $page = Page::where('id', $request->id)->first();

        if ($page) {
            $page->name = $request->name;
            $page->slug = Str::slug($request->slug, '-');
            $page->body = $request->body;
            try {
                $page->save();
                return redirect()->back()->with(['success' => 'Page Updated']);
            } catch (\Illuminate\Database\QueryException $qe) {
                return redirect()->back()->with(['message' => $qe->getMessage()]);
            } catch (Exception $e) {
                return redirect()->back()->with(['message' => $e->getMessage()]);
            } catch (\Throwable $th) {
                return redirect()->back()->with(['message' => $th]);
            }
        } else {
            return redirect()->route('admin.pages');
        }
    }

    /**
     * @param $id
     */
    public function deletePage($id)
    {
        $page = Page::where('id', $id)->first();
        if ($page) {
            $page->delete();
            return redirect()->back()->with(['success' => 'Deleted']);
        } else {
            return redirect()->route('admin.pages');
        }
    }

    public function restaurantpayouts()
    {
        $count = RestaurantPayout::count();

        $restaurantPayouts = RestaurantPayout::paginate(20);

        return view('admin.restaurantPayouts', array(
            'restaurantPayouts' => $restaurantPayouts,
            'count' => $count,
        ));
    }

    /**
     * @param $id
     */
    public function viewRestaurantPayout($id)
    {
        $restaurantPayout = RestaurantPayout::where('id', $id)->first();

        if ($restaurantPayout) {
            return view('admin.viewRestaurantPayout', array(
                'restaurantPayout' => $restaurantPayout,
            ));
        }
    }

    /**
     * @param Request $request
     */
    public function updateRestaurantPayout(Request $request)
    {
        $restaurantPayout = RestaurantPayout::where('id', $request->id)->first();

        if ($restaurantPayout) {
            $restaurantPayout->status = $request->status;
            $restaurantPayout->transaction_mode = $request->transaction_mode;
            $restaurantPayout->transaction_id = $request->transaction_id;
            $restaurantPayout->message = $request->message;
            try {
                $restaurantPayout->save();
                return redirect()->back()->with(['success' => 'Restaurant Payout Updated']);
            } catch (\Illuminate\Database\QueryException $qe) {
                return redirect()->back()->with(['message' => $qe->getMessage()]);
            } catch (Exception $e) {
                return redirect()->back()->with(['message' => $e->getMessage()]);
            } catch (\Throwable $th) {
                return redirect()->back()->with(['message' => $th]);
            }

        }
    }

    /**
     * @return mixed
     */
    /**
     * @param $duplicate
     */
    public function fixUpdateIssues()
    {
        try {

            $duplicates = AcceptDelivery::whereIn('order_id', function ($query) {
                $query->select('order_id')->from('accept_deliveries')->groupBy('order_id')->havingRaw('count(*) > 1');
            })->get();

            foreach ($duplicates as $duplicate) {

                if ($duplicate->is_completed == 0 && ($duplicate->order->orderstatus_id == 5 || $duplicate->order->orderstatus_id == 6)) {
                    //just delete
                    $duplicate->delete(); //delete the duplicate entry in db
                }

                if ($duplicate->is_completed == 0 && $duplicate->order->orderstatus_id == 3) {
                    //delete and change orderstatus to 2
                    $duplicate->order->orderstatus_id = 2; //change order status to not delivery assigned
                    $duplicate->order->save(); //save the order
                    $duplicate->delete(); //delete the duplicate entry in db
                }

            }

            // ** MIGRATE ** //
            //first migrate the db if any new db are avaliable...
            Artisan::call('migrate', [
                '--force' => true,
            ]);
            // ** MIGRATE END ** //

            // ** SETTINGS ** //
            // get the latest settings json file from the server...
            $data = base64_decode('WwoJeyAia2V5IjogInN0b3JlQ29sb3IiLCAidmFsdWUiOiAiI2ZjODAxOSIgfSwKCXsgImtleSI6ICJzcGxhc2hMb2dvIiwgInZhbHVlIjogInNwbGFzaC5qcGciIH0sCgl7ICJrZXkiOiAiZmlyc3RTY3JlZW5IZWFkaW5nIiwgInZhbHVlIjogIk9yZGVyIGZyb20gdG9wICYgZmF2b3VyaXRlIHJlc3RhdXJhbnRzIiB9LAoJeyAia2V5IjogImZpcnN0U2NyZWVuU3ViSGVhZGluZyIsICJ2YWx1ZSI6ICJSZWFkeSB0byBzZWUgdG9wIHJlc3RhdXJhbnQgdG8gb3JkZXI/IiB9LAoJeyAia2V5IjogImZpcnN0U2NyZWVuU2V0dXBMb2NhdGlvbiIsICJ2YWx1ZSI6ICJzZXR1cCB5b3VyIGxvY2F0aW9uIiB9LAoJeyAia2V5IjogImZpcnN0U2NyZWVuTG9naW5UZXh0IiwgInZhbHVlIjogIkhhdmUgYW4gYWNjb3VudD8iIH0sCgl7ICJrZXkiOiAiZm9vdGVyTmVhcm1lIiwgInZhbHVlIjogIk5lYXIgTWUiIH0sCgl7ICJrZXkiOiAiZm9vdGVyRXhwbG9yZSIsICJ2YWx1ZSI6ICJFeHBsb3JlIiB9LAoJeyAia2V5IjogImZvb3RlckNhcnQiLCAidmFsdWUiOiAiQ2FydCIgfSwKCXsgImtleSI6ICJmb290ZXJBY2NvdW50IiwgInZhbHVlIjogIkFjY291bnQiIH0sCgl7ICJrZXkiOiAicmVzdGF1cmFudENvdW50VGV4dCIsICJ2YWx1ZSI6ICJSZXN0YXVyYW50cyBOZWFyIFlvdSIgfSwKCXsgImtleSI6ICJzZWFyY2hBcmVhUGxhY2Vob2xkZXIiLCAidmFsdWUiOiAiU2VhcmNoIHlvdXIgYXJlYS4uLiIgfSwKCXsgImtleSI6ICJzZWFyY2hQb3B1bGFyUGxhY2VzIiwgInZhbHVlIjogIlBvcHVsYXIgUGxhY2VzIiB9LAoJeyAia2V5IjogInJlY29tbWVuZGVkQmFkZ2VUZXh0IiwgInZhbHVlIjogIlJlY29tbWVuZGVkIiB9LAoJeyAia2V5IjogInJlY29tbWVuZGVkQmFkZ2VDb2xvciIsICJ2YWx1ZSI6ICIjZDUzZDRjIiB9LAoJeyAia2V5IjogInBvcHVsYXJCYWRnZVRleHQiLCAidmFsdWUiOiAiUG9wdWxhciIgfSwKCXsgImtleSI6ICJwb3B1bGFyQmFkZ2VDb2xvciIsICJ2YWx1ZSI6ICIjZmY1NzIyIiB9LAoJeyAia2V5IjogIm5ld0JhZGdlVGV4dCIsICJ2YWx1ZSI6ICJOZXciIH0sCgl7ICJrZXkiOiAibmV3QmFkZ2VDb2xvciIsICJ2YWx1ZSI6ICIjMjE5NkYzIiB9LAoJeyAia2V5IjogImN1cnJlbmN5Rm9ybWF0IiwgInZhbHVlIjogIiQiIH0sCgl7ICJrZXkiOiAiY3VycmVuY3lJZCIsICJ2YWx1ZSI6ICJVU0QiIH0sCgl7ICJrZXkiOiAiY2FydENvbG9yQmciLCAidmFsdWUiOiAiIzYwYjI0NiIgfSwKCXsgImtleSI6ICJjYXJ0Q29sb3JUZXh0IiwgInZhbHVlIjogIiNmZmZmZmYiIH0sCgl7ICJrZXkiOiAiY2FydEVtcHR5VGV4dCIsICJ2YWx1ZSI6ICJZb3VyIENhcnQgaXMgRW1wdHkiIH0sCgl7ICJrZXkiOiAiZmlyc3RTY3JlZW5IZXJvSW1hZ2UiLCAidmFsdWUiOiAiYXNzZXRzL2ltZy92YXJpb3VzLzE1NjY2MjgxOTkzOWx6UjNnQjJpLnBuZyIgfSwKCXsgImtleSI6ICJyZXN0YXVyYW50U2VhcmNoUGxhY2Vob2xkZXIiLCAidmFsdWUiOiAiU2VhcmNoIGZvciByZXN0YXVyYW50cyBhbmQgaXRlbXMuLi4iIH0sCgl7ICJrZXkiOiAiYWNjb3VudE1hbmFnZUFkZHJlc3MiLCAidmFsdWUiOiAiTWFuYWdlIEFkZHJlc3MiIH0sCgl7ICJrZXkiOiAiYWNjb3VudE15T3JkZXJzIiwgInZhbHVlIjogIk15IE9yZGVycyIgfSwKCXsgImtleSI6ICJhY2NvdW50SGVscEZhcSIsICJ2YWx1ZSI6ICJIZWxwICYgRkFRcyIgfSwKCXsgImtleSI6ICJhY2NvdW50TG9nb3V0IiwgInZhbHVlIjogIkxvZ291dCIgfSwKCXsgImtleSI6ICJjYXJ0TWFrZVBheW1lbnQiLCAidmFsdWUiOiAiTWFrZSBQYXltZW50IiB9LAoJeyAia2V5IjogImNhcnRMb2dpbkhlYWRlciIsICJ2YWx1ZSI6ICJBbG1vc3QgVGhlcmUiIH0sCgl7ICJrZXkiOiAiY2FydExvZ2luU3ViSGVhZGVyIiwgInZhbHVlIjogIkxvZ2luIG9yIFNpZ251cCB0byBwbGFjZSB5b3VyIG9yZGVyIiB9LAoJeyAia2V5IjogImNhcnRMb2dpbkJ1dHRvblRleHQiLCAidmFsdWUiOiAiQ29udGludWUiIH0sCgl7ICJrZXkiOiAiY2FydERlbGl2ZXJUbyIsICJ2YWx1ZSI6ICJEZWxpdmVyIFRvIiB9LAoJeyAia2V5IjogImNhcnRDaGFuZ2VMb2NhdGlvbiIsICJ2YWx1ZSI6ICJDaGFuZ2UiIH0sCgl7ICJrZXkiOiAiYnV0dG9uTmV3QWRkcmVzcyIsICJ2YWx1ZSI6ICJOZXcgQWRkcmVzcyIgfSwKCXsgImtleSI6ICJidXR0b25TYXZlQWRkcmVzcyIsICJ2YWx1ZSI6ICJTYXZlIEFkZHJlc3MiIH0sCgl7ICJrZXkiOiAiZWRpdEFkZHJlc3NBZGRyZXNzIiwgInZhbHVlIjogIkZsYXQvQXBhcnRtZW50IE51bWJlciIgfSwKCXsgImtleSI6ICJlZGl0QWRkcmVzc0hvdXNlIiwgInZhbHVlIjogIkhvdXNlIC8gRmxhdCBOby4iIH0sCgl7ICJrZXkiOiAiZWRpdEFkZHJlc3NMYW5kbWFyayIsICJ2YWx1ZSI6ICJMYW5kbWFyayIgfSwKCXsgImtleSI6ICJlZGl0QWRkcmVzc1RhZyIsICJ2YWx1ZSI6ICJUYWciIH0sCgl7ICJrZXkiOiAiYWRkcmVzc1RhZ1BsYWNlaG9sZGVyIiwgInZhbHVlIjogIkVnLiBIb21lLCBXb3JrIiB9LAoJeyAia2V5IjogImNhcnRBcHBseUNvdXBvbiIsICJ2YWx1ZSI6ICJBcHBseSBDb3Vwb24iIH0sCgl7ICJrZXkiOiAiY2FydEludmFsaWRDb3Vwb24iLCAidmFsdWUiOiAiSW52YWxpZCBDb3Vwb24iIH0sCgl7ICJrZXkiOiAiY2FydFN1Z2dlc3Rpb25QbGFjZWhvbGRlciIsICJ2YWx1ZSI6ICJTdWdnZXN0aW9uIGZvciB0aGUgcmVzdGF1cmFudC4uLiIgfSwKCXsgImtleSI6ICJlZGl0QWRkcmVzc1RleHQiLCAidmFsdWUiOiAiRWRpdCIgfSwKCXsgImtleSI6ICJkZWxldGVBZGRyZXNzVGV4dCIsICJ2YWx1ZSI6ICJEZWxldGUiIH0sCgl7ICJrZXkiOiAibm9BZGRyZXNzVGV4dCIsICJ2YWx1ZSI6ICJZb3UgZG9uJ3QgaGF2ZSBhbnkgc2F2ZWQgYWRkcmVzc2VzLiIgfSwKCXsgImtleSI6ICJjYXJ0U2V0QWRkcmVzc1RleHQiLCAidmFsdWUiOiAiU2V0IFlvdXIgQWRkcmVzcyIgfSwKCXsgImtleSI6ICJjYXJ0UGFnZVRpdGxlIiwgInZhbHVlIjogIkNhcnQiIH0sCgl7ICJrZXkiOiAiY2hlY2tvdXRQYWdlVGl0bGUiLCAidmFsdWUiOiAiQ2hlY2tvdXQiIH0sCgl7ICJrZXkiOiAiY2hlY2tvdXRQbGFjZU9yZGVyIiwgInZhbHVlIjogIlBsYWNlIE9yZGVyIiB9LAoJeyAia2V5IjogInJ1bm5pbmdPcmRlclBsYWNlZFRpdGxlIiwgInZhbHVlIjogIk9yZGVyIFBsYWNlZCBTdWNjZXNzZnVsbHkiIH0sCgl7ICJrZXkiOiAicnVubmluZ09yZGVyUGxhY2VkU3ViIiwgInZhbHVlIjogIldhaXRpbmcgZm9yIHRoZSByZXN0YXVyYW50IHRvIGNvbmZpcm0geW91ciBvcmRlciIgfSwKCXsgImtleSI6ICJydW5uaW5nT3JkZXJQcmVwYXJpbmdUaXRsZSIsICJ2YWx1ZSI6ICJDaGVmIGF0IHdvcmshISIgfSwKCXsgImtleSI6ICJydW5uaW5nT3JkZXJQcmVwYXJpbmdTdWIiLCAidmFsdWUiOiAiUmVzdGF1cmFudCBpcyBwcmVwYXJpbmcgeW91ciBvcmRlciIgfSwKCXsgImtleSI6ICJydW5uaW5nT3JkZXJPbndheVRpdGxlIiwgInZhbHVlIjogIlZyb29tIFZyb29tISEiIH0sCgl7ICJrZXkiOiAicnVubmluZ09yZGVyT253YXlTdWIiLCAidmFsdWUiOiAiT3JkZXIgaGFzIGJlZW4gcGlja2VkIHVwIGFuZCBpcyBvbiBpdHMgd2F5IiB9LAoJeyAia2V5IjogInJ1bm5pbmdPcmRlclJlZnJlc2hCdXR0b24iLCAidmFsdWUiOiAiUmVmcmVzaCBPcmRlciBTdGF0dXMiIH0sCgl7ICJrZXkiOiAibm9PcmRlcnNUZXh0IiwgInZhbHVlIjogIllvdSBoYXZlIG5vdCBwbGFjZWQgYW55IG9yZGVyIHlldC4iIH0sCgl7ICJrZXkiOiAib3JkZXJUZXh0VG90YWwiLCAidmFsdWUiOiAiVG90YWw6IiB9LAoJeyAia2V5IjogImNoZWNrb3V0UGF5bWVudExpc3RUaXRsZSIsICJ2YWx1ZSI6ICJTZWxlY3QgeW91ciBwcmVmZXJlZCBwYXltZW50IG1ldGhvZCIgfSwKCXsgImtleSI6ICJjaGVja291dFNlbGVjdFBheW1lbnQiLCAidmFsdWUiOiAiU2VsZWN0IFBheW1lbnQgTWV0aG9kIiB9LAoJeyAia2V5IjogIm1hcEFwaUtleSIsICJ2YWx1ZSI6IG51bGwgfSwKCXsgImtleSI6ICJzdG9yZU5hbWUiLCAidmFsdWUiOiAiRm9vZG9tYSIsICJjcmVhdGVkX2F0IjogbnVsbCwgInVwZGF0ZWRfYXQiOiAiMjAxOS0wOC0wMSAwNzoyOTo0NiIgfSwKCXsgImtleSI6ICJzdG9yZUxvZ28iLCAidmFsdWUiOiAibG9nby5wbmciIH0sCgl7ICJrZXkiOiAicnVubmluZ09yZGVyRGVsaXZlcnlBc3NpZ25lZFRpdGxlIiwgInZhbHVlIjogIkRlbGl2ZXJ5IEd1eSBBc3NpZ25lZCIgfSwKCXsgImtleSI6ICJydW5uaW5nT3JkZXJEZWxpdmVyeUFzc2lnbmVkU3ViIiwgInZhbHVlIjogIk9uIHRoZSB3YXkgdG8gcGljayB1cCB5b3VyIG9yZGVyLiIgfSwKCXsgImtleSI6ICJydW5uaW5nT3JkZXJDYW5jZWxlZFRpdGxlIiwgInZhbHVlIjogIk9yZGVyIENhbmNlbGVkIiB9LAoJeyAia2V5IjogInJ1bm5pbmdPcmRlckNhbmNlbGVkU3ViIiwgInZhbHVlIjogIlNvcnJ5LiBZb3VyIG9yZGVyIGhhcyBiZWVuIGNhbmNlbGVkLiIgfSwKCXsgImtleSI6ICJzdHJpcGVQdWJsaWNLZXkiLCAidmFsdWUiOiBudWxsIH0sCgl7ICJrZXkiOiAic3RyaXBlU2VjcmV0S2V5IiwgInZhbHVlIjogbnVsbCB9LAoJeyAia2V5IjogImZpcnN0U2NyZWVuV2VsY29tZU1lc3NhZ2UiLCAidmFsdWUiOiAiV2VsY29tZSwiIH0sCgl7ICJrZXkiOiAiZmlyc3RTY3JlZW5Mb2dpbkJ0biIsICJ2YWx1ZSI6ICJMb2dpbiIgfSwKCXsgImtleSI6ICJsb2dpbkVycm9yTWVzc2FnZSIsICJ2YWx1ZSI6ICJXb29wc3MhISBTb21ldGhpbmcgd2VudCB3cm9uZy4gUGxlYXNlIHRyeSBhZ2Fpbi4iIH0sCgl7ICJrZXkiOiAicGxlYXNlV2FpdFRleHQiLCAidmFsdWUiOiAiUGxlYXNlIFdhaXQuLi4iIH0sCgl7ICJrZXkiOiAibG9naW5Mb2dpblRpdGxlIiwgInZhbHVlIjogIkxPR0lOIiB9LAoJeyAia2V5IjogImxvZ2luTG9naW5TdWJUaXRsZSIsICJ2YWx1ZSI6ICJFbnRlciB5b3VyIGVtYWlsIGFuZCBwYXNzd29yZCIgfSwKCXsgImtleSI6ICJsb2dpbkxvZ2luRW1haWxMYWJlbCIsICJ2YWx1ZSI6ICJFbWFpbCIgfSwKCXsgImtleSI6ICJsb2dpbkxvZ2luUGFzc3dvcmRMYWJlbCIsICJ2YWx1ZSI6ICJQYXNzd29yZCIgfSwKCXsgImtleSI6ICJob21lUGFnZU1pbnNUZXh0IiwgInZhbHVlIjogIk1JTlMiIH0sCgl7ICJrZXkiOiAiaG9tZVBhZ2VGb3JUd29UZXh0IiwgInZhbHVlIjogIkZPUiBUV08iIH0sCgl7ICJrZXkiOiAiaXRlbXNQYWdlUmVjb21tZW5kZWRUZXh0IiwgInZhbHVlIjogIlJFQ09NTUVOREVEIiB9LAoJeyAia2V5IjogImZsb2F0Q2FydEl0ZW1zVGV4dCIsICJ2YWx1ZSI6ICJJdGVtcyIgfSwKCXsgImtleSI6ICJmbG9hdENhcnRWaWV3Q2FydFRleHQiLCAidmFsdWUiOiAiVmlldyBDYXJ0IiB9LAoJeyAia2V5IjogImNhcnRJdGVtc0luQ2FydFRleHQiLCAidmFsdWUiOiAiSXRlbXMgaW4gQ2FydCIgfSwKCXsgImtleSI6ICJjYXJ0QmlsbERldGFpbHNUZXh0IiwgInZhbHVlIjogIkJpbGwgRGV0YWlscyIgfSwKCXsgImtleSI6ICJjYXJ0SXRlbVRvdGFsVGV4dCIsICJ2YWx1ZSI6ICJJdGVtIFRvdGFsIiB9LAoJeyAia2V5IjogImNhcnRSZXN0YXVyYW50Q2hhcmdlcyIsICJ2YWx1ZSI6ICJSZXN0YXVyYW50IENoYXJnZXMiIH0sCgl7ICJrZXkiOiAiY2FydERlbGl2ZXJ5Q2hhcmdlcyIsICJ2YWx1ZSI6ICJEZWxpdmVyeSBDaGFyZ2VzIiB9LAoJeyAia2V5IjogImNhcnRDb3Vwb25UZXh0IiwgInZhbHVlIjogIkNvdXBvbiIgfSwKCXsgImtleSI6ICJjYXJ0VG9QYXlUZXh0IiwgInZhbHVlIjogIlRvIFBheSIgfSwKCXsgImtleSI6ICJjYXJ0U2V0WW91ckFkZHJlc3MiLCAidmFsdWUiOiAiU2V0IFlvdXIgQWRkcmVzcyIgfSwKCXsgImtleSI6ICJjaGVja291dFBheW1lbnRJblByb2Nlc3MiLCAidmFsdWUiOiAiUGF5bWVudCBpbiBwcm9jZXNzLiBEbyBub3QgaGl0IHJlZnJlc2ggb3IgZ28gYmFjay4iIH0sCgl7ICJrZXkiOiAiY2hlY2tvdXRTdHJpcGVUZXh0IiwgInZhbHVlIjogIlN0cmlwZSIgfSwKCXsgImtleSI6ICJjaGVja291dFN0cmlwZVN1YlRleHQiLCAidmFsdWUiOiAiT25saW5lIFBheW1lbnQiIH0sCgl7ICJrZXkiOiAiY2hlY2tvdXRDb2RUZXh0IiwgInZhbHVlIjogIkNPRCIgfSwKCXsgImtleSI6ICJjaGVja291dENvZFN1YlRleHQiLCAidmFsdWUiOiAiQ2FzaCBPbiBEZWxpdmVyeSIgfSwKCXsgImtleSI6ICJzaG93UHJvbW9TbGlkZXIiLCAidmFsdWUiOiAiZmFsc2UiIH0sCgl7ICJrZXkiOiAibG9naW5Mb2dpblBob25lTGFiZWwiLCAidmFsdWUiOiAiUGhvbmUiIH0sCgl7ICJrZXkiOiAibG9naW5Mb2dpbk5hbWVMYWJlbCIsICJ2YWx1ZSI6ICJOYW1lIiB9LAoJeyAia2V5IjogInJlZ2lzdGVyRXJyb3JNZXNzYWdlIiwgInZhbHVlIjogIldvcHBzcyEhIFNvbWV0aGluZyB3ZW50IHdyb25nLiBQbGVhc2UgdHJ5IGFnYWluLiIgfSwKCXsgImtleSI6ICJyZWdpc3RlclJlZ2lzdGVyVGl0bGUiLCAidmFsdWUiOiAiUmVnaXN0ZXIiIH0sCgl7ICJrZXkiOiAicmVnaXN0ZXJSZWdpc3RlclN1YlRpdGxlIiwgInZhbHVlIjogIlJlZ3NpdGVyIG5vdyBmb3IgZnJlZSIgfSwKCXsgImtleSI6ICJmaXJzdFNjcmVlblJlZ2lzdGVyQnRuIiwgInZhbHVlIjogIlJlZ2lzdGVyIiB9LAoJeyAia2V5IjogImxvZ2luRG9udEhhdmVBY2NvdW50IiwgInZhbHVlIjogIkRvbid0IGhhdmUgYW4gYWNjb3VudCB5ZXQ/ICIgfSwKCXsgImtleSI6ICJyZWdzaXRlckFscmVhZHlIYXZlQWNjb3VudCIsICJ2YWx1ZSI6ICJBbHJlYWR5IGhhdmUgYW4gYWNjb3VudD8gIiB9LAoJeyAia2V5IjogImZhdmljb24tMTZ4MTYiLCAidmFsdWUiOiAiZmF2aWNvbi0xNngxNi5wbmciIH0sCgl7ICJrZXkiOiAiZmF2aWNvbi0zMngzMiIsICJ2YWx1ZSI6ICJmYXZpY29uLTMyeDMyLnBuZyIgfSwKCXsgImtleSI6ICJmYXZpY29uLTk2eDk2IiwgInZhbHVlIjogImZhdmljb24tOTZ4OTYucG5nIiB9LAoJeyAia2V5IjogImZhdmljb24tMTI4eDEyOCIsICJ2YWx1ZSI6ICJmYXZpY29uLTEyOHgxMjgucG5nIiB9LAoJeyAia2V5IjogInN0b3JlRW1haWwiLCAidmFsdWUiOiAiY2FyZUBzdG9yZS5jb20iIH0sCgl7ICJrZXkiOiAic2VvTWV0YVRpdGxlIiwgInZhbHVlIjogbnVsbCB9LAoJeyAia2V5IjogInNlb01ldGFEZXNjcmlwdGlvbiIsICJ2YWx1ZSI6IG51bGwgfSwKCXsgImtleSI6ICJzdG9yZVVybCIsICJ2YWx1ZSI6IG51bGwgfSwKCXsgImtleSI6ICJ0d2l0dGVyVXNlcm5hbWUiLCAidmFsdWUiOiAidHdpdHRlci11c2VybmFtZSIgfSwKCXsgImtleSI6ICJzZW9PZ1RpdGxlIiwgInZhbHVlIjogbnVsbCB9LAoJeyAia2V5IjogInNlb09nRGVzY3JpcHRpb24iLCAidmFsdWUiOiBudWxsIH0sCgl7ICJrZXkiOiAic2VvVHdpdHRlclRpdGxlIiwgInZhbHVlIjogbnVsbCB9LAoJeyAia2V5IjogInNlb1R3aXR0ZXJEZXNjcmlwdGlvbiIsICJ2YWx1ZSI6IG51bGwgfSwKCXsgImtleSI6ICJzZW9PZ0ltYWdlIiwgInZhbHVlIjogbnVsbCB9LAoJeyAia2V5IjogInNlb1R3aXR0ZXJJbWFnZSIsICJ2YWx1ZSI6IG51bGwgfSwKCXsgImtleSI6ICJhY2NvdW50TXlBY2NvdW50IiwgInZhbHVlIjogIk15IEFjY291bnQiIH0sCgl7ICJrZXkiOiAiZGVza3RvcEhlYWRpbmciLCAidmFsdWUiOiAiT3JkZXIgZnJvbSByZXN0YXVyYW50cyBuZWFyIHlvdSIgfSwKCXsKCQkia2V5IjogImRlc2t0b3BTdWJIZWFkaW5nIiwKCQkidmFsdWUiOiAiRWFzeSB3YXkgdG8gZ2V0IHRoZSBmb29kIHlvdSBsb3ZlIGRlbGl2ZXJlZC5cclxuV2UgYnJpbmcgZm9vZCBmcm9tIHRoZSBiZXN0IHJlc3RhdXJhbnRzIGFuZCBkZXNzZXJ0cyB0byB5b3VyIGRvb3JzdGVwLiBXZSBoYXZlIDxiIHN0eWxlPVwiXCI+aHVuZHJlZHM8L2I+IG9mIHJlc3RhdXJhbnRzIHRvIGNob29zZSBmcm9tLiIKCX0sCgl7ICJrZXkiOiAiZGVza3RvcFVzZUFwcEJ1dHRvbiIsICJ2YWx1ZSI6ICJVc2UgQXBwIiB9LAoJeyAia2V5IjogImRlc2t0b3BBY2hpZXZlbWVudE9uZVRpdGxlIiwgInZhbHVlIjogIlJlc3RhdXJhbnRzIiB9LAoJeyAia2V5IjogImRlc2t0b3BBY2hpZXZlbWVudE9uZVN1YiIsICJ2YWx1ZSI6ICIyMzAwKyIgfSwKCXsgImtleSI6ICJkZXNrdG9wQWNoaWV2ZW1lbnRUd29UaXRsZSIsICJ2YWx1ZSI6ICJJdGVtcyIgfSwKCXsgImtleSI6ICJkZXNrdG9wQWNoaWV2ZW1lbnRUd29TdWIiLCAidmFsdWUiOiAiNjUwMDArIiB9LAoJeyAia2V5IjogImRlc2t0b3BBY2hpZXZlbWVudFRocmVlVGl0bGUiLCAidmFsdWUiOiAiQ3VzdG9tZXJzIiB9LAoJeyAia2V5IjogImRlc2t0b3BBY2hpZXZlbWVudFRocmVlU3ViIiwgInZhbHVlIjogIjFNKyIgfSwKCXsgImtleSI6ICJkZXNrdG9wQWNoaWV2ZW1lbnRGb3VyVGl0bGUiLCAidmFsdWUiOiAiRGVsaXZlcmllcyIgfSwKCXsgImtleSI6ICJkZXNrdG9wQWNoaWV2ZW1lbnRGb3VyU3ViIiwgInZhbHVlIjogIjVNKyIgfSwKCXsgImtleSI6ICJkZXNrdG9wU29jaWFsRmFjZWJvb2tMaW5rIiwgInZhbHVlIjogImh0dHBzOi8vd3d3LmZhY2Vib29rLmNvbSIgfSwKCXsgImtleSI6ICJkZXNrdG9wU29jaWFsR29vZ2xlTGluayIsICJ2YWx1ZSI6ICJodHRwczovL3d3dy5nb29nbGUuY29tIiB9LAoJeyAia2V5IjogImRlc2t0b3BTb2NpYWxZb3V0dWJlTGluayIsICJ2YWx1ZSI6IG51bGwgfSwKCXsgImtleSI6ICJkZXNrdG9wU29jaWFsSW5zdGFncmFtTGluayIsICJ2YWx1ZSI6ICJodHRwczovL3d3dy5pbnN0YWdyYW0uY29tIiB9LAoJeyAia2V5IjogImRlc2t0b3BGb290ZXJTb2NpYWxIZWFkZXIiLCAidmFsdWUiOiAiV2UgQXJlIFNvY2lhbCIgfSwKCXsgImtleSI6ICJkZXNrdG9wRm9vdGVyQWRkcmVzcyIsICJ2YWx1ZSI6ICIjMTIwMSwgU29tZXBsYWNlLCBOZWFyIFNvbWV3aGVyZSIgfSwKCXsgImtleSI6ICJydW5uaW5nT3JkZXJEZWxpdmVyeVBpbiIsICJ2YWx1ZSI6ICJEZWxpdmVyeSBQaW46ICIgfSwKCXsgImtleSI6ICJkZWxpdmVyeU5vT3JkZXJzQWNjZXB0ZWQiLCAidmFsdWUiOiAiTm8gT3JkZXJzIEFjY2VwdGVkIFlldCIgfSwKCXsgImtleSI6ICJkZWxpdmVyeU5vTmV3T3JkZXJzIiwgInZhbHVlIjogIk5vIE5ldyBPcmRlcnMgWWV0IiB9LAoJeyAia2V5IjogImZpcnN0U2NyZWVuSGVyb0ltYWdlU20iLCAidmFsdWUiOiAiYXNzZXRzL2ltZy92YXJpb3VzLzE1NjY2MjgxOTkzOWx6UjNnQjJpLXNtLnBuZyIgfSwKCXsgImtleSI6ICJzaG93TWFwIiwgInZhbHVlIjogImZhbHNlIiB9LAoJeyAia2V5IjogInBheXBhbEVudiIsICJ2YWx1ZSI6ICJzYW5kYm94IiB9LAoJeyAia2V5IjogInBheXBhbFNhbmRib3hLZXkiLCAidmFsdWUiOiBudWxsIH0sCgl7ICJrZXkiOiAicGF5cGFsUHJvZHVjdGlvbktleSIsICJ2YWx1ZSI6IG51bGwgfSwKCXsgImtleSI6ICJlbmFibGVQdXNoTm90aWZpY2F0aW9uIiwgInZhbHVlIjogImZhbHNlIiB9LAoJeyAia2V5IjogImVuYWJsZVB1c2hOb3RpZmljYXRpb25PcmRlcnMiLCAidmFsdWUiOiAiZmFsc2UiIH0sCgl7ICJrZXkiOiAiZmlyZWJhc2VTZW5kZXJJZCIsICJ2YWx1ZSI6ICI1ODc2NTYwNjgzMzMiIH0sCgl7ICJrZXkiOiAiZmlyZWJhc2VTZWNyZXQiLCAidmFsdWUiOiBudWxsIH0sCgl7ICJrZXkiOiAicnVubmluZ09yZGVyRGVsaXZlcmVkIiwgInZhbHVlIjogIk9yZGVyIERlbGl2ZXJlZCIgfSwKCXsgImtleSI6ICJydW5uaW5nT3JkZXJEZWxpdmVyZWRTdWIiLCAidmFsdWUiOiAiVGhlIG9yZGVyIGhhcyBiZWVuIGRlbGl2ZXJlZCB0byB5b3UuIEVuam95LiIgfSwKCXsgImtleSI6ICJzaG93R2RwciIsICJ2YWx1ZSI6ICJmYWxzZSIgfSwKCXsKCQkia2V5IjogImdkcHJNZXNzYWdlIiwKCQkidmFsdWUiOiAiV2UgdXNlIENvb2tpZXMgdG8gZ2l2ZSB5b3UgdGhlIGJlc3QgcG9zc2libGUgc2VydmljZS4gQnkgY29udGludWluZyB0byBicm93c2Ugb3VyIHNpdGUgeW91IGFyZSBhZ3JlZWluZyB0byBvdXIgdXNlIG9mIENvb2tpZXMiCgl9LAoJeyAia2V5IjogImdkcHJDb25maXJtQnV0dG9uIiwgInZhbHVlIjogIk9rYXkiIH0sCgl7ICJrZXkiOiAicmVzdGF1cmFudEZlYXR1cmVkVGV4dCIsICJ2YWx1ZSI6ICJGZWF0dXJlZCIgfSwKCXsgImtleSI6ICJkZWxpdmVyeU5ld09yZGVyc1RpdGxlIiwgInZhbHVlIjogIk5ldyBPcmRlcnMiIH0sCgl7ICJrZXkiOiAiZGVsaXZlcnlBY2NlcHRlZE9yZGVyc1RpdGxlIiwgInZhbHVlIjogIkFjY2VwdGVkIE9yZGVycyIgfSwKCXsgImtleSI6ICJkZWxpdmVyeVdlbGNvbWVNZXNzYWdlIiwgInZhbHVlIjogIldlbGNvbWUiIH0sCgl7ICJrZXkiOiAiZGVsaXZlcnlPcmRlckl0ZW1zIiwgInZhbHVlIjogIk9yZGVyIEl0ZW1zIiB9LAoJeyAia2V5IjogImRlbGl2ZXJ5UmVzdGF1cmFudEFkZHJlc3MiLCAidmFsdWUiOiAiUmVzdGF1cmFudCBBZGRyZXNzIiB9LAoJeyAia2V5IjogImRlbGl2ZXJ5R2V0RGlyZWN0aW9uQnV0dG9uIiwgInZhbHVlIjogIkdldCBEaXJlY3Rpb24iIH0sCgl7ICJrZXkiOiAiZGVsaXZlcnlEZWxpdmVyeUFkZHJlc3MiLCAidmFsdWUiOiAiRGVsaXZlcnkgQWRkcmVzcyIgfSwKCXsgImtleSI6ICJkZWxpdmVyeU9ubGluZVBheW1lbnQiLCAidmFsdWUiOiAiT25saW5lIFBheW1lbnQiIH0sCgl7ICJrZXkiOiAiZGVsaXZlcnlEZWxpdmVyeVBpblBsYWNlaG9sZGVyIiwgInZhbHVlIjogIkVOVEVSIERFTElWRVJZIFBJTiIgfSwKCXsgImtleSI6ICJkZWxpdmVyeUFjY2VwdE9yZGVyQnV0dG9uIiwgInZhbHVlIjogIkFjY2VwdCIgfSwKCXsgImtleSI6ICJkZWxpdmVyeVBpY2tlZFVwQnV0dG9uIiwgInZhbHVlIjogIlBpY2tlZCBVcCIgfSwKCXsgImtleSI6ICJkZWxpdmVyeURlbGl2ZXJlZEJ1dHRvbiIsICJ2YWx1ZSI6ICJEZWxpdmVyZWQiIH0sCgl7ICJrZXkiOiAiZGVsaXZlcnlPcmRlckNvbXBsZXRlZEJ1dHRvbiIsICJ2YWx1ZSI6ICJPcmRlciBDb21wbGV0ZWQiIH0sCgl7ICJrZXkiOiAiZGVsaXZlcnlJbnZhbGlkRGVsaXZlcnlQaW4iLCAidmFsdWUiOiAiSW5jb3JyZWN0IGRlbGl2ZXJ5IHBpbi4gUGxlYXNlIHRyeSBhZ2Fpbi4iIH0sCgl7ICJrZXkiOiAiZGVsaXZlcnlBbHJlYWR5QWNjZXB0ZWQiLCAidmFsdWUiOiAiVGhpcyBkZWxpdmVyeSBoYXMgYmVlbiBhY2NlcHRlZCBieSBzb21lb25lIGVsc2UuIiB9LAoJeyAia2V5IjogImRlbGl2ZXJ5TG9nb3V0RGVsaXZlcnkiLCAidmFsdWUiOiAiTG9nb3V0IERlbGl2ZXJ5IiB9LAoJeyAia2V5IjogImVuYWJsZUdvb2dsZUFuYWx5dGljcyIsICJ2YWx1ZSI6ICJmYWxzZSIgfSwKCXsgImtleSI6ICJnb29nbGVBbmFseXRpY3NJZCIsICJ2YWx1ZSI6IG51bGwgfSwKCXsgImtleSI6ICJ0YXhBcHBsaWNhYmxlIiwgInZhbHVlIjogImZhbHNlIiB9LAoJeyAia2V5IjogInRheFBlcmNlbnRhZ2UiLCAidmFsdWUiOiBudWxsIH0sCgl7CgkJImtleSI6ICJmaXJlYmFzZVB1YmxpYyIsCgkJInZhbHVlIjogIkJINUw4WHJHc05wa2k1dUYxMDA4RmJaemdLS1pOLU5taE93ZFdMNUx4aDVyM25zZ1o2Tl9EZ2VkMUlZWFhDQ0p3cG5yWHpzNTJHX3Yzdk1fbmFPMGh4WSIKCX0sCgl7ICJrZXkiOiAiZGVsaXZlcnlMb2dvdXRDb25maXJtYXRpb24iLCAidmFsdWUiOiAiQXJlIHlvdSBzdXJlPyIgfSwKCXsgImtleSI6ICJjdXN0b21pemF0aW9uSGVhZGluZyIsICJ2YWx1ZSI6ICJDdXN0b21pemF0aW9ucyIgfSwKCXsgImtleSI6ICJjdXN0b21pemFibGVJdGVtVGV4dCIsICJ2YWx1ZSI6ICJDdXN0b21pemFibGUiIH0sCgl7ICJrZXkiOiAiY3VzdG9taXphdGlvbkRvbmVCdG5UZXh0IiwgInZhbHVlIjogIkNvbnRpbnVlIiB9LAoJeyAia2V5IjogInBheXN0YWNrUHVibGljS2V5IiwgInZhbHVlIjogInBrX3Rlc3RfZWNmMzQ5NmJkZjM2YmNlZDIxMTJhNTAyZjVmNWJiOTZlMTM0MDEyNCIgfSwKCXsgImtleSI6ICJwYXlzdGFja1ByaXZhdGVLZXkiLCAidmFsdWUiOiBudWxsIH0sCgl7ICJrZXkiOiAicGF5c3RhY2tQYXlUZXh0IiwgInZhbHVlIjogIlBBWSBXSVRIIFBBWVNMQUNLIiB9LAoJeyAia2V5IjogIm1pblBheW91dCIsICJ2YWx1ZSI6ICIxNTAiIH0sCgl7ICJrZXkiOiAiZW5hYmxlRmFjZWJvb2tMb2dpbiIsICJ2YWx1ZSI6ICJmYWxzZSIgfSwKCXsgImtleSI6ICJmYWNlYm9va0FwcElkIiwgInZhbHVlIjogbnVsbCB9LAoJeyAia2V5IjogImZhY2Vib29rTG9naW5CdXR0b25UZXh0IiwgInZhbHVlIjogIkxvZ2luIHdpdGggRmFjZWJvb2siIH0sCgl7ICJrZXkiOiAiZW5hYmxlR29vZ2xlTG9naW4iLCAidmFsdWUiOiAiZmFsc2UiIH0sCgl7ICJrZXkiOiAiZ29vZ2xlQXBwSWQiLCAidmFsdWUiOiBudWxsIH0sCgl7ICJrZXkiOiAiZ29vZ2xlTG9naW5CdXR0b25UZXh0IiwgInZhbHVlIjogIkxvZ2luIHdpdGggR29vZ2xlIiB9LAoJeyAia2V5IjogImN1c3RvbUNTUyIsICJ2YWx1ZSI6IG51bGwgfSwKCXsgImtleSI6ICJlblNPViIsICJ2YWx1ZSI6ICJmYWxzZSIgfSwKCXsgImtleSI6ICJ0d2lsaW9TaWQiLCAidmFsdWUiOiBudWxsIH0sCgl7ICJrZXkiOiAidHdpbGlvQWNjZXNzVG9rZW4iLCAidmFsdWUiOiBudWxsIH0sCgl7ICJrZXkiOiAidHdpbGlvU2VydmljZUlkIiwgInZhbHVlIjogbnVsbCB9LAoJeyAia2V5IjogImZpZWxkVmFsaWRhdGlvbk1zZyIsICJ2YWx1ZSI6ICJUaGlzIGlzIGEgcmVxdWlyZWQgZmllbGQuIiB9LAoJeyAia2V5IjogIm5hbWVWYWxpZGF0aW9uTXNnIiwgInZhbHVlIjogIlBsZWFzZSBlbnRlciB5b3VyIGZ1bGwgbmFtZS4iIH0sCgl7ICJrZXkiOiAiZW1haWxWYWxpZGF0aW9uTXNnIiwgInZhbHVlIjogIlBsZWFzZSBlbnRlciBhIHZhbGlkIGVtYWlsLiIgfSwKCXsgImtleSI6ICJwaG9uZVZhbGlkYXRpb25Nc2ciLCAidmFsdWUiOiAiUGxlYXNlIGVudGVyIGEgcGhvbmUgbnVtYmVyIGluIHRoaXMgZm9ybWF0OiArMTEyMzQ1Njc4OSIgfSwKCXsgImtleSI6ICJtaW5pbXVtTGVuZ3RoVmFsaWRhdGlvbk1lc3NhZ2UiLCAidmFsdWUiOiAiVGhpcyBmaWVsZCBtdXN0IGJlIGF0IGxlYXN0IDggY2hhcmFjdGVycyBsb25nLiIgfSwKCXsgImtleSI6ICJlbWFpbFBob25lQWxyZWFkeVJlZ2lzdGVyZWQiLCAidmFsdWUiOiAiRW1haWwgb3IgUGhvbmUgaGFzIGFscmVhZHkgYmVlbiByZWdpc3RlcmVkLiIgfSwKCXsgImtleSI6ICJlbnRlclBob25lVG9WZXJpZnkiLCAidmFsdWUiOiAiUGxlYXNlIGVudGVyIHlvdXIgcGhvbmUgbnVtYmVyIHRvIHZlcmlmeSIgfSwKCXsgImtleSI6ICJpbnZhbGlkT3RwTXNnIiwgInZhbHVlIjogIkludmFsaWQgT1RQLiBQbGVhc2UgY2hlY2sgYW5kIHRyeSBhZ2Fpbi4iIH0sCgl7ICJrZXkiOiAib3RwU2VudE1zZyIsICJ2YWx1ZSI6ICJBbiBPVFAgaGFzIGJlZW4gc2VudCB0byAiIH0sCgl7ICJrZXkiOiAicmVzZW5kT3RwTXNnIiwgInZhbHVlIjogIlJlc2VuZCBPVFAgdG8gIiB9LAoJeyAia2V5IjogInJlc2VuZE90cENvdW50ZG93bk1zZyIsICJ2YWx1ZSI6ICJSZXNlbmQgT1RQIGluICIgfSwKCXsgImtleSI6ICJ2ZXJpZnlPdHBCdG5UZXh0IiwgInZhbHVlIjogIlZlcmlmeSBPVFAiIH0sCgl7ICJrZXkiOiAic29jaWFsV2VsY29tZVRleHQiLCAidmFsdWUiOiAiSGkgIiB9LAoJeyAia2V5IjogImVtYWlsUGFzc0Rvbm90TWF0Y2giLCAidmFsdWUiOiAiRW1haWwgJiBQYXNzd29yZCBkbyBub3QgbWF0Y2guIiB9LAoJeyAia2V5IjogImVuU1BVIiwgInZhbHVlIjogInRydWUiIH0sCgl7ICJrZXkiOiAicnVubmluZ09yZGVyUmVhZHlGb3JQaWNrdXAiLCAidmFsdWUiOiAiRm9vZCBpcyBSZWFkeSIgfSwKCXsgImtleSI6ICJydW5uaW5nT3JkZXJSZWFkeUZvclBpY2t1cFN1YiIsICJ2YWx1ZSI6ICJZb3VyIG9yZGVyIGlzIHJlYWR5IGZvciBzZWxmIHBpY2t1cC4iIH0sCgl7ICJrZXkiOiAiZGVsaXZlcnlUeXBlRGVsaXZlcnkiLCAidmFsdWUiOiAiRGVsaXZlcnkiIH0sCgl7ICJrZXkiOiAiZGVsaXZlcnlUeXBlU2VsZlBpY2t1cCIsICJ2YWx1ZSI6ICJTZWxmIFBpY2t1cCIgfSwKCXsgImtleSI6ICJub1Jlc3RhdXJhbnRNZXNzYWdlIiwgInZhbHVlIjogIk5vIHJlc3RhdXJhbnRzIGFyZSBhdmFpbGFibGUuIiB9LAoJeyAia2V5IjogInNlbGVjdGVkU2VsZlBpY2t1cE1lc3NhZ2UiLCAidmFsdWUiOiAiWW91IGhhdmUgc2VsZWN0ZWQgU2VsZiBQaWNrdXAuIiB9LAoJeyAia2V5IjogInZlaGljbGVUZXh0IiwgInZhbHVlIjogIlZlaGljbGU6IiB9LAoJeyAia2V5IjogImRlbGl2ZXJ5R3V5QWZ0ZXJOYW1lIiwgInZhbHVlIjogImlzIHlvdXIgZGVsaXZlcnkgdmFsZXQgdG9kYXkuIiB9LAoJeyAia2V5IjogImNhbGxOb3dCdXR0b24iLCAidmFsdWUiOiAiQ2FsbCBOb3ciIH0sCgl7ICJrZXkiOiAiZW5hYmxlR29vZ2xlQVBJIiwgInZhbHVlIjogImZhbHNlIiB9LAoJeyAia2V5IjogImNoZWNrb3V0UmF6b3JwYXlUZXh0IiwgInZhbHVlIjogIlJhem9ycGF5IiB9LAoJeyAia2V5IjogImNoZWNrb3V0UmF6b3JwYXlTdWJUZXh0IiwgInZhbHVlIjogIlBheSB3aXRoIGNhcmRzLCB3YWxsZXQgb3IgVVBJIiB9LAoJeyAia2V5IjogInJhem9ycGF5S2V5SWQiLCAidmFsdWUiOiAicnpwX3Rlc3RfVldjcDg2bmZVNlQ3clYiIH0sCgl7ICJrZXkiOiAicmF6b3JwYXlLZXlTZWNyZXQiLCAidmFsdWUiOiAiZUx6TUJyMWN5Y1JHMGlFamdNcHRnak1zIiB9LAoJeyAia2V5IjogImFsbG93TG9jYXRpb25BY2Nlc3NNZXNzYWdlIiwgInZhbHVlIjogIktpbmRseSBhbGxvdyBsb2NhdGlvbiBhY2Nlc3MgZm9yIGxpdmUgdHJhY2tpbmcuIiB9LAoJeyAia2V5IjogImVuYWJsZURlbGl2ZXJ5UGluIiwgInZhbHVlIjogInRydWUiIH0sCgl7ICJrZXkiOiAiZGVsaXZlcnlPcmRlcnNSZWZyZXNoQnRuIiwgInZhbHVlIjogIlJlZnJlc2giIH0sCgl7ICJrZXkiOiAicmVzdGF1cmFudEFjY2VwdFRpbWVUaHJlc2hvbGQiLCAidmFsdWUiOiAiMTAiIH0sCgl7ICJrZXkiOiAiZGVsaXZlcnlBY2NlcHRUaW1lVGhyZXNob2xkIiwgInZhbHVlIjogIjQ1IiB9LAoJeyAia2V5IjogInRheFRleHQiLCAidmFsdWUiOiAiVGF4IiB9LAoJeyAia2V5IjogIml0ZW1zUmVtb3ZlZE1zZyIsICJ2YWx1ZSI6ICJJdGVtcyBhZGRlZCBmcm9tIHRoZSBwcmV2aW91cyByZXN0YXVyYW50IGhhdmUgYmVlbiByZW1vdmVkLiIgfSwKCXsgImtleSI6ICJvbmdvaW5nT3JkZXJNc2ciLCAidmFsdWUiOiAiWW91IGhhdmUgc29tZSBvbi1nb2luZyBvcmRlcnMuIFZJRVciIH0sCgl7ICJrZXkiOiAidHJhY2tPcmRlclRleHQiLCAidmFsdWUiOiAiVHJhY2sgT3JkZXIiIH0sCgl7ICJrZXkiOiAib3JkZXJQbGFjZWRTdGF0dXNUZXh0IiwgInZhbHVlIjogIk9yZGVyIFBsYWNlZCIgfSwKCXsgImtleSI6ICJwcmVwYXJpbmdPcmRlclN0YXR1c1RleHQiLCAidmFsdWUiOiAiUHJlcGFyaW5nIE9yZGVyIiB9LAoJeyAia2V5IjogImRlbGl2ZXJ5R3V5QXNzaWduZWRTdGF0dXNUZXh0IiwgInZhbHVlIjogIkRlbGl2ZXJ5IEd1eSBBc3NpZ25lZCIgfSwKCXsgImtleSI6ICJvcmRlclBpY2tlZFVwU3RhdHVzVGV4dCIsICJ2YWx1ZSI6ICJPcmRlciBQaWNrZWQgVXAiIH0sCgl7ICJrZXkiOiAiZGVsaXZlcmVkU3RhdHVzVGV4dCIsICJ2YWx1ZSI6ICJEZWxpdmVyZWQiIH0sCgl7ICJrZXkiOiAiY2FuY2VsZWRTdGF0dXNUZXh0IiwgInZhbHVlIjogIkNhbmNlbGVkIiB9LAoJeyAia2V5IjogInJlYWR5Rm9yUGlja3VwU3RhdHVzVGV4dCIsICJ2YWx1ZSI6ICJSZWFkeSBGb3IgUGlja3VwIiB9LAoJeyAia2V5IjogInB1cmVWZWdUZXh0IiwgInZhbHVlIjogIlB1cmUgVmVnIiB9LAoJeyAia2V5IjogImNlcnRpZmljYXRlQ29kZVRleHQiLCAidmFsdWUiOiAiQ2VydGlmaWNhdGUgQ29kZTogIiB9LAoJeyAia2V5IjogInNob3dNb3JlQnV0dG9uVGV4dCIsICJ2YWx1ZSI6ICJTaG93IE1vcmUiIH0sCgl7ICJrZXkiOiAic2hvd0xlc3NCdXR0b25UZXh0IiwgInZhbHVlIjogIlNob3cgTGVzcyIgfSwKCXsgImtleSI6ICJ3YWxsZXROYW1lIiwgInZhbHVlIjogIldhbGxldCIgfSwKCXsgImtleSI6ICJhY2NvdW50TXlXYWxsZXQiLCAidmFsdWUiOiAiTXkgV2FsbGV0IiB9LAoJeyAia2V5IjogIm5vV2FsbGV0VHJhbnNhY3Rpb25zVGV4dCIsICJ2YWx1ZSI6ICJObyBXYWxsZXQgVHJhbnNhY3Rpb25zIFlldCEhISIgfSwKCXsgImtleSI6ICJ3YWxsZXREZXBvc2l0VGV4dCIsICJ2YWx1ZSI6ICJEZXBvc2l0IiB9LAoJeyAia2V5IjogIndhbGxldFdpdGhkcmF3VGV4dCIsICJ2YWx1ZSI6ICJXaXRoZHJhdyIgfSwKCXsgImtleSI6ICJwYXlQYXJ0aWFsV2l0aFdhbGxldFRleHQiLCAidmFsdWUiOiAiUGF5IHBhcnRpYWwgYW1vdW50IHdpdGggd2FsbGV0IiB9LAoJeyAia2V5IjogIndpbGxiZURlZHVjdGVkVGV4dCIsICJ2YWx1ZSI6ICJ3aWxsIGJlIGRlZHVjdGVkIGZyb20geW91ciBiYWxhbmNlIG9mIiB9LAoJeyAia2V5IjogInBheUZ1bGxXaXRoV2FsbGV0VGV4dCIsICJ2YWx1ZSI6ICJQYXkgZnVsbCBhbW91bnQgd2l0aCBXYWxsZXQuIiB9LAoJeyAia2V5IjogIm9yZGVyUGF5bWVudFdhbGxldENvbW1lbnQiLCAidmFsdWUiOiAiUGF5bWVudCBmb3Igb3JkZXI6IiB9LAoJeyAia2V5IjogIm9yZGVyUGFydGlhbFBheW1lbnRXYWxsZXRDb21tZW50IiwgInZhbHVlIjogIlBhcnRpYWwgcGF5bWVudCBmb3Igb3JkZXI6IiB9LAoJeyAia2V5IjogIm9yZGVyUmVmdW5kV2FsbGV0Q29tbWVudCIsICJ2YWx1ZSI6ICJSZWZ1bmQgZm9yIG9yZGVyIGNhbmNlbGxhdGlvbi4iIH0sCgl7ICJrZXkiOiAib3JkZXJQYXJ0aWFsUmVmdW5kV2FsbGV0Q29tbWVudCIsICJ2YWx1ZSI6ICJQYXJ0aWFsIFJlZnVuZCBmb3Igb3JkZXIgY2FuY2VsbGF0aW9uLiIgfSwKCXsgImtleSI6ICJlbkRldk1vZGUiLCAidmFsdWUiOiAidHJ1ZSIgfSwKCXsgImtleSI6ICJ3YWxsZXRSZWRlZW1CdG5UZXh0IiwgInZhbHVlIjogIlJlZGVlbSIgfSwKCXsgImtleSI6ICJyZXN0YXVyYW50TmV3T3JkZXJOb3RpZmljYXRpb25Nc2ciLCAidmFsdWUiOiAiQSBOZXcgT3JkZXIgaGFzIEFycml2ZWQgISEhIiB9LAoJeyAia2V5IjogInJlc3RhdXJhbnROZXdPcmRlck5vdGlmaWNhdGlvbk1zZ1N1YiIsICJ2YWx1ZSI6ICJOZXcgT3JkZXIgTm90aWZpY2F0aW9uIiB9LAoJeyAia2V5IjogImRlbGl2ZXJ5R3V5TmV3T3JkZXJOb3RpZmljYXRpb25Nc2ciLCAidmFsdWUiOiAiQSBOZXcgT3JkZXIgaXMgV2FpdGluZyAhISEiIH0sCgl7ICJrZXkiOiAiZGVsaXZlcnlHdXlOZXdPcmRlck5vdGlmaWNhdGlvbk1zZ1N1YiIsICJ2YWx1ZSI6ICJOZXcgT3JkZXIgTm90aWZpY2F0aW9uIiB9LAoJeyAia2V5IjogImZpcmViYXNlU0RLU25pcHBldCIsICJ2YWx1ZSI6ICIiIH0sCgl7ICJrZXkiOiAiY2FydENvdXBvbk9mZlRleHQiLCAidmFsdWUiOiAiT0ZGIiB9LAoJeyAia2V5IjogIndpbGxCZVJlZnVuZGVkVGV4dCIsICJ2YWx1ZSI6ICJ3aWxsIGJlIHJlZnVuZGVkIGJhY2sgdG8geW91ciB3YWxsZXQuIiB9LAoJewoJCSJrZXkiOiAid2lsbE5vdEJlUmVmdW5kZWRUZXh0IiwKCQkidmFsdWUiOiAiTm8gUmVmdW5kIHdpbGwgYmUgbWFkZSB0byB5b3VyIHdhbGxldCBhcyB0aGUgcmVzdGF1cmFudCBoYXMgYWxyZWFkeSBwcmVwYXJlZCB0aGUgb3JkZXIuIgoJfSwKCXsgImtleSI6ICJjYXJ0UmVzdGF1cmFudE5vdE9wZXJhdGlvbmFsIiwgInZhbHVlIjogIlJlc3RhdXJhbnQgaXMgbm90IG9wZXJhdGlvbmFsIG9uIHlvdXIgc2VsZWN0ZWQgbG9jYXRpb24uIiB9LAoJeyAia2V5IjogImFkZHJlc3NEb2Vzbm90RGVsaXZlclRvVGV4dCIsICJ2YWx1ZSI6ICJEb2VzIG5vdCBkZWxpdmVyIHRvIiB9LAoJeyAia2V5IjogImdvb2dsZUFwaUtleSIsICJ2YWx1ZSI6ICIiIH0sCgl7ICJrZXkiOiAidXNlQ3VycmVudExvY2F0aW9uVGV4dCIsICJ2YWx1ZSI6ICJVc2UgQ3VycmVudCBMb2NhdGlvbiIgfSwKCXsgImtleSI6ICJncHNBY2Nlc3NOb3RHcmFudGVkTXNnIiwgInZhbHVlIjogIkdQUyBhY2Nlc3MgaXMgbm90IGdyYW50ZWQgb3Igd2FzIGRlbmllZC4iIH0sCgl7ICJrZXkiOiAieW91ckxvY2F0aW9uVGV4dCIsICJ2YWx1ZSI6ICJZT1VSIExPQ0FUSU9OIiB9LAoJeyAia2V5IjogIm5vdEFjY2VwdGluZ09yZGVyc01zZyIsICJ2YWx1ZSI6ICJDdXJyZW50bHkgTm90IEFjY2VwdGluZyBBbnkgT3JkZXJzIiB9LAoJeyAia2V5IjogImV4cGxvcmVSZXN0YXV0YW50c1RleHQiLCAidmFsdWUiOiAiUkVTVEFVUkFOVFMiIH0sCgl7ICJrZXkiOiAiZXhwbG9yZUl0ZW1zVGV4dCIsICJ2YWx1ZSI6ICJJVEVNUyIgfSwKCXsgImtleSI6ICJoaWRlUHJpY2VXaGVuWmVybyIsICJ2YWx1ZSI6ICJ0cnVlIiB9LAoJeyAia2V5IjogInBob25lQ291bnRyeUNvZGUiLCAidmFsdWUiOiAiKzEiIH0sCgl7ICJrZXkiOiAib3JkZXJDYW5jZWxsYXRpb25Db25maXJtYXRpb25UZXh0IiwgInZhbHVlIjogIkRvIHlvdSB3YW50IHRvIGNhbmNlbCB0aGlzIG9yZGVyPyIgfSwKCXsgImtleSI6ICJ5ZXNDYW5jZWxPcmRlckJ0biIsICJ2YWx1ZSI6ICJZZXMsIENhbmNlbCBPcmRlciIgfSwKCXsgImtleSI6ICJjYW5jZWxHb0JhY2tCdG4iLCAidmFsdWUiOiAiR28gYmFjayIgfSwKCXsgImtleSI6ICJjYW5jZWxPcmRlck1haW5CdXR0b24iLCAidmFsdWUiOiAiQ2FuY2VsIE9yZGVyIiB9LAoJeyAia2V5IjogImRlbGl2ZXJ5T3JkZXJQbGFjZWRUZXh0IiwgInZhbHVlIjogIk9yZGVyIFBsYWNlZCIgfSwKCXsgImtleSI6ICJkZWxpdmVyeUNhc2hPbkRlbGl2ZXJ5IiwgInZhbHVlIjogIkNhc2ggT24gRGVsaXZlcnkiIH0sCgl7ICJrZXkiOiAic29jaWFsTG9naW5PclRleHQiLCAidmFsdWUiOiAiT1IiIH0sCgl7ICJrZXkiOiAib3JkZXJDYW5jZWxsZWRUZXh0IiwgInZhbHVlIjogIk9yZGVyIENhbmNlbGxlZCIgfSwKCXsgImtleSI6ICJzZWFyY2hBdGxlYXN0VGhyZWVDaGFyc01zZyIsICJ2YWx1ZSI6ICJFbnRlciBhdCBsZWFzdCAzIGNoYXJhY3RlcnMgdG8gc2VhcmNoLiIgfSwKCXsgImtleSI6ICJtdWx0aUxhbmd1YWdlU2VsZWN0aW9uIiwgInZhbHVlIjogInRydWUiIH0sCgl7ICJrZXkiOiAiY2hhbmdlTGFuZ3VhZ2VUZXh0IiwgInZhbHVlIjogIkNoYW5nZSBMYW5ndWFnZSIgfSwKCXsgImtleSI6ICJkZWxpdmVyeUZvb3Rlck5ld1RpdGxlIiwgInZhbHVlIjogIk5ldyBPcmRlcnMiIH0sCgl7ICJrZXkiOiAiZGVsaXZlcnlGb290ZXJBY2NlcHRlZFRpdGxlIiwgInZhbHVlIjogIkFjY2VwdGVkIiB9LAoJeyAia2V5IjogImRlbGl2ZXJ5Rm9vdGVyQWNjb3VudCIsICJ2YWx1ZSI6ICJBY2NvdW50IiB9LAoJeyAia2V5IjogImVuYWJsZURlbGl2ZXJ5R3V5RWFybmluZyIsICJ2YWx1ZSI6ICJmYWxzZSIgfSwKCXsgImtleSI6ICJkZWxpdmVyeUd1eUNvbW1pc3Npb25Gcm9tIiwgInZhbHVlIjogIkZVTExPUkRFUiIgfSwKCXsgImtleSI6ICJkZWxpdmVyeUVhcm5pbmdzVGV4dCIsICJ2YWx1ZSI6ICJFYXJuaW5ncyIgfSwKCXsgImtleSI6ICJkZWxpdmVyeU9uR29pbmdUZXh0IiwgInZhbHVlIjogIk9uLUdvaW5nIiB9LAoJeyAia2V5IjogImRlbGl2ZXJ5Q29tcGxldGVkVGV4dCIsICJ2YWx1ZSI6ICJDb21wbGV0ZWQiIH0sCgl7ICJrZXkiOiAiZGVsaXZlcnlDb21taXNzaW9uTWVzc2FnZSIsICJ2YWx1ZSI6ICJDb21taXNzaW9uIGZvciBvcmRlcjogIiB9LAoJeyAia2V5IjogIml0ZW1TZWFyY2hUZXh0IiwgInZhbHVlIjogIlNlYXJjaCByZXN1bHRzIGZvcjogIiB9LAoJeyAia2V5IjogIml0ZW1TZWFyY2hOb1Jlc3VsdFRleHQiLCAidmFsdWUiOiAiTm8gcmVzdWx0cyBmb3VuZCBmb3I6ICIgfSwKCXsgImtleSI6ICJpdGVtU2VhcmNoUGxhY2Vob2xkZXIiLCAidmFsdWUiOiAiU2VhcmNoIGZvciBpdGVtcy4uLiIgfSwKCXsgImtleSI6ICJnb29nbGVBcGlLZXlJUCIsICJ2YWx1ZSI6IG51bGwgfSwKCXsgImtleSI6ICJpdGVtc01lbnVCdXR0b25UZXh0IiwgInZhbHVlIjogIk1FTlUiIH0sCgl7ICJrZXkiOiAiZW5QYXNzUmVzZXRFbWFpbCIsICJ2YWx1ZSI6ICJmYWxzZSIgfSwKCXsgImtleSI6ICJtYWlsX2hvc3QiLCAidmFsdWUiOiBudWxsIH0sCgl7ICJrZXkiOiAibWFpbF9wb3J0IiwgInZhbHVlIjogbnVsbCB9LAoJeyAia2V5IjogIm1haWxfdXNlcm5hbWUiLCAidmFsdWUiOiBudWxsIH0sCgl7ICJrZXkiOiAibWFpbF9wYXNzd29yZCIsICJ2YWx1ZSI6IG51bGwgfSwKCXsgImtleSI6ICJtYWlsX2VuY3J5cHRpb24iLCAidmFsdWUiOiBudWxsIH0sCgl7ICJrZXkiOiAiZW5SZXN0YXVyYW50Q2F0ZWdvcnlTbGlkZXIiLCAidmFsdWUiOiBmYWxzZSB9LAoJeyAia2V5IjogInJlc3RhdXJhbnRDYXRlZ29yeVNsaWRlclBvc2l0aW9uIiwgInZhbHVlIjogIjIiIH0sCgl7ICJrZXkiOiAicmVzdGF1cmFudENhdGVnb3J5U2xpZGVyU2l6ZSIsICJ2YWx1ZSI6ICIzIiB9LAoJeyAia2V5IjogInNob3dSZXN0YXVyYW50Q2F0ZWdvcnlTbGlkZXJMYWJlbCIsICJ2YWx1ZSI6ICJmYWxzZSIgfSwKCXsgImtleSI6ICJyZXN0YXVyYW50Q2F0ZWdvcnlTbGlkZXJTdHlsZSIsICJ2YWx1ZSI6ICIwLjQiIH0sCgl7ICJrZXkiOiAiZW5SQVIiLCAidmFsdWUiOiAidHJ1ZSIgfSwKCXsgImtleSI6ICJyYXJNb2RFbkhvbWVCYW5uZXIiLCAidmFsdWUiOiAidHJ1ZSIgfSwKCXsgImtleSI6ICJyYXJNb2RTaG93QmFubmVyUmVzdGF1cmFudE5hbWUiLCAidmFsdWUiOiAidHJ1ZSIgfSwKCXsgImtleSI6ICJyYXJNb2RIb21lQmFubmVyUG9zaXRpb24iLCAidmFsdWUiOiAiMiIgfSwKCXsgImtleSI6ICJyYXJNb2RIb21lQmFubmVyQmdDb2xvciIsICJ2YWx1ZSI6ICJyZ2IoMjU1LCAyMzUsIDU5KSIgfSwKCXsgImtleSI6ICJyYXJNb2RIb21lQmFubmVyVGV4dENvbG9yIiwgInZhbHVlIjogInJnYigwLCAwLCAwKSIgfSwKCXsgImtleSI6ICJyYXJNb2RIb21lQmFubmVyU3RhcnNDb2xvciIsICJ2YWx1ZSI6ICJyZ2IoMjU1LCAxNjIsIDApIiB9LAoJeyAia2V5IjogInJhck1vZEhvbWVCYW5uZXJUZXh0IiwgInZhbHVlIjogIlJhdGUgYW5kIFJldmlldyIgfSwKCXsgImtleSI6ICJyYXJNb2RSYXRpbmdQYWdlVGl0bGUiLCAidmFsdWUiOiAiUmF0ZSBZb3VyIE9yZGVyIiB9LAoJeyAia2V5IjogInJhck1vZERlbGl2ZXJ5UmF0aW5nVGl0bGUiLCAidmFsdWUiOiAiUmF0ZSB0aGUgRGVsaXZlcnkiIH0sCgl7ICJrZXkiOiAicmFyTW9kUmVzdGF1cmFudFJhdGluZ1RpdGxlIiwgInZhbHVlIjogIlJhdGUgdGhlIFJlc3RhdXJhbnQiIH0sCgl7ICJrZXkiOiAicmFyUmV2aWV3Qm94VGl0bGUiLCAidmFsdWUiOiAiWW91ciBGZWVkYmFjayIgfSwKCXsgImtleSI6ICJyYXJSZXZpZXdCb3hUZXh0UGxhY2VIb2xkZXJUZXh0IiwgInZhbHVlIjogIldyaXRlIHlvdXIgZmVlZGJhY2sgaGVyZSAob3B0aW9uYWwpIiB9LAoJeyAia2V5IjogInJhclN1Ym1pdEJ1dHRvblRleHQiLCAidmFsdWUiOiAiU3VibWl0IiB9LAoJeyAia2V5IjogInNob3dQZXJjZW50YWdlRGlzY291bnQiLCAidmFsdWUiOiAidHJ1ZSIgfSwKCXsgImtleSI6ICJpdGVtUGVyY2VudGFnZURpc2NvdW50VGV4dCIsICJ2YWx1ZSI6ICIlIE9GRiIgfSwKCXsgImtleSI6ICJzaG93VmVnTm9uVmVnQmFkZ2UiLCAidmFsdWUiOiAidHJ1ZSIgfSwKCXsgImtleSI6ICJleHBsb3JlTm9SZXN1bHRzIiwgInZhbHVlIjogIk5vIEl0ZW1zIG9yIFJlc3RhdXJhbnRzIEZvdW5kIiB9LAoJeyAia2V5IjogInVwZGF0aW5nTWVzc2FnZSIsICJ2YWx1ZSI6ICJVcGRhdGluZyBTeXN0ZW0iIH0sCgl7ICJrZXkiOiAidXNlck5vdEZvdW5kRXJyb3JNZXNzYWdlIiwgInZhbHVlIjogIk5vIHVzZXIgZm91bmQgd2l0aCB0aGlzIGVtYWlsLiIgfSwKCXsgImtleSI6ICJpbnZhbGlkT3RwRXJyb3JNZXNzYWdlIiwgInZhbHVlIjogIkludmFsaWQgT1RQIEVudGVyZWQiIH0sCgl7ICJrZXkiOiAicmVzZXRQYXNzd29yZFBhZ2VUaXRsZSIsICJ2YWx1ZSI6ICJSZXNldCBQYXNzd29yZCIgfSwKCXsgImtleSI6ICJyZXNldFBhc3N3b3JkUGFnZVN1YlRpdGxlIiwgInZhbHVlIjogIkVudGVyIHlvdXIgZW1haWwgYWRkcmVzcyB0byBjb250aW51ZSIgfSwKCXsgImtleSI6ICJzZW5kT3RwT25FbWFpbEJ1dHRvblRleHQiLCAidmFsdWUiOiAiU2VuZCBPVFAgb24gRW1haWwiIH0sCgl7ICJrZXkiOiAiYWxyZWFkeUhhdmVSZXNldE90cEJ1dHRvblRleHQiLCAidmFsdWUiOiAiSSBhbHJlYWR5IGhhdmUgYW4gT1RQIiB9LAoJeyAia2V5IjogImVudGVyUmVzZXRPdHBNZXNzYWdlVGV4dCIsICJ2YWx1ZSI6ICJFbnRlciB0aGUgT1RQIHNlbnQgdG8geW91IGVtYWlsIiB9LAoJeyAia2V5IjogInZlcmlmeVJlc2V0T3RwQnV0dG9uVGV4dCIsICJ2YWx1ZSI6ICJWZXJpZnkgT1RQIiB9LAoJeyAia2V5IjogImRvbnRIYXZlUmVzZXRPdHBCdXR0b25UZXh0IiwgInZhbHVlIjogIkkgZG9udCBoYXZlIGFuIE9UUCIgfSwKCXsgImtleSI6ICJlbnRlck5ld1Bhc3N3b3JkVGV4dCIsICJ2YWx1ZSI6ICJQbGVhc2UgZW50ZXIgYSBuZXcgcGFzc3dvcmQgYmVsb3ciIH0sCgl7ICJrZXkiOiAibmV3UGFzc3dvcmRMYWJlbFRleHQiLCAidmFsdWUiOiAiTmV3IFBhc3N3b3JkIiB9LAoJeyAia2V5IjogInNldE5ld1Bhc3N3b3JkQnV0dG9uVGV4dCIsICJ2YWx1ZSI6ICJTZXQgTmV3IFBhc3N3b3JkIiB9LAoJeyAia2V5IjogImV4bHBvcmVCeVJlc3RhdXJhbnRUZXh0IiwgInZhbHVlIjogIkJ5IiB9LAoJeyAia2V5IjogImZvcmdvdFBhc3N3b3JkTGlua1RleHQiLCAidmFsdWUiOiAiRm9yZ290IFBhc3N3b3JkPyIgfSwKCXsgImtleSI6ICJjYXRlZ29yaWVzTm9SZXN0YXVyYW50c0ZvdW5kVGV4dCIsICJ2YWx1ZSI6ICJObyBSZXN0YXVyYW50cyBGb3VuZCIgfSwKCXsgImtleSI6ICJjYXRlZ29yaWVzRmlsdGVyc1RleHQiLCAidmFsdWUiOiAiRmlsdGVycyIgfSwKCXsgImtleSI6ICJzZW5kRW1haWxGcm9tRW1haWxBZGRyZXNzIiwgInZhbHVlIjogImRvLW5vdC1yZXBseUBmb29kb21hYS5jb20iIH0sCgl7ICJrZXkiOiAic2VuZEVtYWlsRnJvbUVtYWlsTmFtZSIsICJ2YWx1ZSI6ICJGb29kb21hYSIgfSwKCXsgImtleSI6ICJwYXNzd29yZFJlc2V0RW1haWxTdWJqZWN0IiwgInZhbHVlIjogIlJlc2V0IFBhc3N3b3JkIE9UUCIgfSwKCXsgImtleSI6ICJyZWdpc3RyYXRpb25Qb2xpY3lNZXNzYWdlIiwgInZhbHVlIjogbnVsbCB9LAoJeyAia2V5IjogImxvY2F0aW9uU2F2ZWRBZGRyZXNzZXMiLCAidmFsdWUiOiAiU2F2ZWQgQWRkcmVzc2VzIiB9LAoJeyAia2V5IjogInJlc3RhdXJhbnRNaW5PcmRlck1lc3NhZ2UiLCAidmFsdWUiOiAiTWluIGNhcnQgdmFsdWUgc2hvdWxkIGJlIGF0bGVhc3QgIiB9LAoJeyAia2V5IjogImZvb3RlckFsZXJ0cyIsICJ2YWx1ZSI6ICJBbGVydHMiIH0sCgl7ICJrZXkiOiAic2hvd0Zyb21Ob3dEYXRlIiwgInZhbHVlIjogInRydWUiIH0sCgl7ICJrZXkiOiAibWFya0FsbEFsZXJ0UmVhZFRleHQiLCAidmFsdWUiOiAiTWFyayBhbGwgcmVhZCIgfSwKCXsgImtleSI6ICJub05ld0FsZXJ0c1RleHQiLCAidmFsdWUiOiAiTm8gbmV3IGFsZXJ0cyIgfSwKCXsgImtleSI6ICJjdXJyZW5jeVN5bWJvbEFsaWduIiwgInZhbHVlIjogImxlZnQiIH0sCgl7ICJrZXkiOiAicmVzdGF1cmFudE5vdGlmaWNhdGlvbkF1ZGlvVHJhY2siLCAidmFsdWUiOiAiQWxlcnQtNSIgfSwKCXsgImtleSI6ICJyZXN0YXVyYW50TmV3T3JkZXJSZWZyZXNoUmF0ZSIsICJ2YWx1ZSI6ICIxNSIgfSwKCXsgImtleSI6ICJlbkRlbENoclJuZCIsICJ2YWx1ZSI6ICJ0cnVlIiB9LAoJeyAia2V5IjogImV4cGFuZEFsbEl0ZW1NZW51IiwgInZhbHVlIjogInRydWUiIH0sCgl7ICJrZXkiOiAibXNnOTFBdXRoS2V5IiwgInZhbHVlIjogbnVsbCB9LAoJeyAia2V5IjogIm1zZzkxU2VuZGVySWQiLCAidmFsdWUiOiBudWxsIH0sCgl7ICJrZXkiOiAiZGVmYXVsdFNtc0dhdGV3YXkiLCAidmFsdWUiOiAiMSIgfSwKCXsgImtleSI6ICJvdHBNZXNzYWdlIiwgInZhbHVlIjogIllvdXIgT1RQIHZlcmlmaWNhdGlvbiBjb2RlIGlzOiAiIH0sCgl7ICJrZXkiOiAidHdpbGlvRnJvbVBob25lIiwgInZhbHVlIjogbnVsbCB9LAoJeyAia2V5IjogInNtc1Jlc3RhdXJhbnROb3RpZnkiLCAidmFsdWUiOiAiZmFsc2UiIH0sCgl7ICJrZXkiOiAic21zRGVsaXZlcnlOb3RpZnkiLCAidmFsdWUiOiAiZmFsc2UiIH0sCgl7ICJrZXkiOiAiZGVmYXVsdFNtc1Jlc3RhdXJhbnRNc2ciLCAidmFsdWUiOiAiWW91IGhhdmUgcmVjZWl2ZWQgYSBuZXcgb3JkZXIuIiB9LAoJeyAia2V5IjogInNtc1Jlc3RPcmRlclZhbHVlIiwgInZhbHVlIjogImZhbHNlIiB9LAoJeyAia2V5IjogInNtc09yZGVyTm90aWZ5IiwgInZhbHVlIjogImZhbHNlIiB9LAoJeyAia2V5IjogImRlZmF1bHRTbXNEZWxpdmVyeU1zZyIsICJ2YWx1ZSI6ICJBIG5ldyBvcmRlciBoYXMgYXJyaXZlZC4iIH0sCgl7ICJrZXkiOiAic2hvd09yZGVyQWRkb25zRGVsaXZlcnkiLCAidmFsdWUiOiAidHJ1ZSIgfSwKCXsgImtleSI6ICJzaG93RGVsaXZlcnlGdWxsQWRkcmVzc09uTGlzdCIsICJ2YWx1ZSI6ICJ0cnVlIiB9LAoJeyAia2V5IjogInNlbmRncmlkX2FwaV9rZXkiLCAidmFsdWUiOiBudWxsIH0sCgl7ICJrZXkiOiAic2hvd1VzZXJJbmZvQmVmb3JlUGlja3VwIiwgInZhbHVlIjogInRydWUiIH0sCgl7ICJrZXkiOiAicmVjb21tZW5kZWRMYXlvdXRWMiIsICJ2YWx1ZSI6ICJ0cnVlIiB9LAoJeyAia2V5IjogImNhcnRJdGVtTm90QXZhaWxhYmxlIiwgInZhbHVlIjogIkl0ZW0gTm90IEF2YWlsYWJsZSIgfSwKCXsgImtleSI6ICJjYXJ0UmVtb3ZlSXRlbUJ1dHRvbiIsICJ2YWx1ZSI6ICJSZW1vdmUgSXRlbSIgfSwKCXsgImtleSI6ICJkZWxpdmVyeVRvdGFsRWFybmluZ3NUZXh0IiwgInZhbHVlIjogIlRvdGFsIEVhcm5pbmdzIiB9LAoJeyAia2V5IjogImZsYXRBcGFydG1lbnRBZGRyZXNzUmVxdWlyZWQiLCAidmFsdWUiOiAiZmFsc2UiIH0sCgl7ICJrZXkiOiAiZGVsaXZlcnlVc2VQaG9uZVRvQWNjZXNzTXNnIiwgInZhbHVlIjogIlVzZSB5b3VyIG1vYmlsZSBwaG9uZSB0byBsb2dpbiB0byB0aGUgRGVsaXZlcnkgQXBwbGljYXRpb24uIiB9LAoJeyAia2V5IjogInJlc3RhdXJhbnROb3RBY3RpdmVNc2ciLCAidmFsdWUiOiAiTm90IEFjY2VwdGluZyBPcmRlcnMiIH0sCgl7ICJrZXkiOiAidXBsb2FkSW1hZ2VRdWFsaXR5IiwgInZhbHVlIjogIjc1IiB9LAoJeyAia2V5IjogImRlbGl2ZXJ5TWF4T3JkZXJSZWFjaGVkTXNnIiwgInZhbHVlIjogIk1heCBPcmRlciBMaW1pdCBSZWFjaGVkIiB9LAoJeyAia2V5IjogInNob3dJbkFjdGl2ZUl0ZW1zVG9vIiwgInZhbHVlIjogImZhbHNlIiB9LAoJeyAia2V5IjogImVuR0RNQSIsICJ2YWx1ZSI6ICJmYWxzZSIgfSwKCXsgImtleSI6ICJzaG93UHJpY2VBbmRPcmRlckNvbW1lbnRzRGVsaXZlcnkiLCAidmFsdWUiOiAiZmFsc2UiIH0sCgl7ICJrZXkiOiAidXNlU2ltcGxlU3Bpbm5lciIsICJ2YWx1ZSI6ICJmYWxzZSIgfSwKCXsgImtleSI6ICJyYW5kb21pemVTdG9yZXMiLCAidmFsdWUiOiAiZmFsc2UiIH0sCgl7ICJrZXkiOiAic2hvd0NvdXBvbkRlc2NyaXB0aW9uT25TdWNjZXNzIiwgInZhbHVlIjogImZhbHNlIiB9LAoJeyAia2V5IjogImNob29zZUF2YXRhclRleHQiLCAidmFsdWUiOiAiQ2hvb3NlIHlvdXIgYXZhdGFyIiB9LAoJeyAia2V5IjogInN0cmlwZUFjY2VwdEFsaVBheSIsICJ2YWx1ZSI6ICJmYWxzZSIgfSwKCXsgImtleSI6ICJzdHJpcGVBY2NlcHRCaXRDb2luIiwgInZhbHVlIjogImZhbHNlIiB9LAoJeyAia2V5IjogInN0cmlwZUxvY2FsZSIsICJ2YWx1ZSI6ICJhdXRvIiB9LAoJeyAia2V5IjogImN1c3RvbUNhcnRNZXNzYWdlIiwgInZhbHVlIjogIjxwPjxicj48L3A+IiB9LAoJeyAia2V5IjogImN1c3RvbUhvbWVNZXNzYWdlIiwgInZhbHVlIjogIjxwPjxicj48L3A+IiB9LAoJeyAia2V5IjogImluQXBwQ2xvc2VCdXR0b24iLCAidmFsdWUiOiAiQ2xvc2UiIH0sCgl7ICJrZXkiOiAiaW5BcHBPcGVuTGlua0J1dHRvbiIsICJ2YWx1ZSI6ICJPcGVuIiB9LAoJeyAia2V5IjogImlPU1BXQVBvcHVwVGl0bGUiLCAidmFsdWUiOiAiQWRkIHRvIEhvbWUgU2NyZWVuIiB9LAoJewoJCSJrZXkiOiAiaU9TUFdBUG9wdXBCb2R5IiwKCQkidmFsdWUiOiAiVGhpcyB3ZWJzaXRlIGhhcyBhcHAgZnVuY3Rpb25hbGl0eS4gQWRkIGl0IHRvIHlvdXIgaG9tZSBzY3JlZW4gdG8gdXNlIGl0IGluIGZ1bGxzY3JlZW4gYW5kIHdoaWxlIG9mZmxpbmUuIgoJfSwKCXsgImtleSI6ICJpT1NQV0FQb3B1cFNoYXJlQnV0dG9uTGFiZWwiLCAidmFsdWUiOiAiMSkgUHJlc3MgdGhlICdTaGFyZScgYnV0dG9uIiB9LAoJeyAia2V5IjogImlPU1BXQVBvcHVwQWRkQnV0dG9uTGFiZWwiLCAidmFsdWUiOiAiMikgUHJlc3MgJ0FkZCB0byBIb21lIFNjcmVlbiciIH0sCgl7ICJrZXkiOiAiaU9TUFdBUG9wdXBDbG9zZUJ1dHRvbkxhYmVsIiwgInZhbHVlIjogIkNhbmNlbCIgfSwKCXsgImtleSI6ICJkZWZhdWx0RW1haWxHYXRld2F5IiwgInZhbHVlIjogInNlbmRncmlkIiB9LAoJeyAia2V5IjogImVuSU9TUFdBUG9wdXAiLCAidmFsdWUiOiAidHJ1ZSIgfSwKCXsgImtleSI6ICJvZmZsaW5lVGl0bGVNZXNzYWdlIiwgInZhbHVlIjogIllvdSBBcmUgT2ZmbGluZSIgfSwKCXsgImtleSI6ICJvZmZsaW5lU3ViVGl0bGVNZXNzYWdlIiwgInZhbHVlIjogIlBsZWFzZSBjaGVjayB5b3VyIGludGVybmV0IGNvbm5lY3Rpb24uIiB9LAoJeyAia2V5IjogInVzZXJJbkFjdGl2ZU1lc3NhZ2UiLCAidmFsdWUiOiAiWW91IGFyZSBiYW5uZWQgZnJvbSBwbGFjaW5nIG9yZGVycyIgfQpd');
            $data = json_decode($data);
            if (!$data) {
                $data = file_get_contents(storage_path('data/data.json'));
                $data = json_decode($data);
            }
            $dbSet = [];
            foreach ($data as $s) {
                //check if the setting key already exists, if exists, do nothing..
                $settingAlreadyExists = Setting::where('key', $s->key)->first();
                //else create an array of settings which doesnt exists...
                if (!$settingAlreadyExists) {
                    $dbSet[] = [
                        'key' => $s->key,
                        'value' => $s->value,
                    ];
                }
            }
            //insert new settings keys into settings table.
            DB::table('settings')->insert($dbSet);
            // ** SETTINGS END ** //

            // ** PAYMENTGATEWAYS ** //
            // check if paystack is installed
            $hasPayStack = PaymentGateway::where('name', 'PayStack')->first();
            if (!$hasPayStack) {
                //if not, then install new payment gateway "PayStack"
                $payStackPaymentGateway = new PaymentGateway();
                $payStackPaymentGateway->name = 'PayStack';
                $payStackPaymentGateway->description = 'PayStack Payment Gateway';
                $payStackPaymentGateway->is_active = 0;
                $payStackPaymentGateway->save();
            }
            // check if razorpay is installed
            $hasRazorPay = PaymentGateway::where('name', 'Razorpay')->first();
            if (!$hasRazorPay) {
                //if not, then install new payment gateway "PayStack"
                $razorPayPaymentGateway = new PaymentGateway();
                $razorPayPaymentGateway->name = 'Razorpay';
                $razorPayPaymentGateway->description = 'Razorpay Payment Gateway';
                $razorPayPaymentGateway->is_active = 0;
                $razorPayPaymentGateway->save();
            }
            // ** END PAYMENTGATEWAYS ** //

            $hasMsg91 = SmsGateway::where('gateway_name', 'MSG91')->first();
            if (!$hasMsg91) {
                //if not, then install new sms gateway gateway "MSG91"
                $msg91Gateway = new SmsGateway();
                $msg91Gateway->gateway_name = 'MSG91';
                $msg91Gateway->save();
            }

            $hasTwilio = SmsGateway::where('gateway_name', 'TWILIO')->first();
            if (!$hasTwilio) {
                //if not, then install new sms gateway gateway "TWILIO"
                $twilioGateway = new SmsGateway();
                $twilioGateway->gateway_name = 'TWILIO';
                $twilioGateway->save();
            }

            // ** ORDERSTATUS ** //
            // check if ready status is inserted
            $hasReadyOrderStatus = Orderstatus::where('id', '7')->first();
            if (!$hasReadyOrderStatus) {
                //if not, then insert it.
                $orderStatus = new Orderstatus();
                $orderStatus->name = 'Ready For Pick Up';
                $orderStatus->save();
            }
            // ** END ORDERSTATUS ** //

            // ** CHANGEURL ** //
            $jsFiles = glob(base_path('static/js') . '/*');
            foreach ($jsFiles as $file) {
                //read the entire string
                $str = file_get_contents($file);
                $baseUrl = substr(url('/'), 0, strrpos(url('/'), '/'));
                //replace string
                $str = str_replace('http://127.0.0.1/swiggy-laravel-react', $baseUrl, $str);
                //write the entire string
                file_put_contents($file, $str);
            }

            /** CLEAR LARAVEL CACHES **/
            Artisan::call('cache:clear');
            Artisan::call('view:clear');
            /** END CLEAR LARAVEL CACHES **/

            return redirect()->back()->with(['success' => 'Operation Successful']);
        } catch (\Illuminate\Database\QueryException $qe) {
            return redirect()->back()->with(['message' => $qe->getMessage()]);
        } catch (Exception $e) {
            return redirect()->back()->with(['message' => $e->getMessage()]);
        } catch (\Throwable $th) {
            return redirect()->back()->with(['message' => $th]);
        }

    }

    /**
     * @param Request $request
     */
    public function addMoneyToWallet(Request $request)
    {
        $user = User::where('id', $request->user_id)->first();

        if ($user) {
            try {
                $user->deposit($request->add_amount * 100, ['description' => $request->add_amount_description]);

                $alert = new PushNotify();
                $alert->sendWalletAlert($request->user_id, $request->add_amount, $request->add_amount_description, $type = 'deposit');

                return redirect()->back()->with(['success' => config('settings.walletName') . ' Updated']);
            } catch (\Illuminate\Database\QueryException $qe) {
                return redirect()->back()->with(['message' => $qe->getMessage()]);
            } catch (Exception $e) {
                return redirect()->back()->with(['message' => $e->getMessage()]);
            } catch (\Throwable $th) {
                return redirect()->back()->with(['message' => $th]);
            }
        }
    }

    /**
     * @param Request $request
     */
    public function substractMoneyFromWallet(Request $request)
    {
        $user = User::where('id', $request->user_id)->first();

        if ($user) {
            if ($user->balanceFloat * 100 >= $request->substract_amount * 100) {
                try {
                    $user->withdraw($request->substract_amount * 100, ['description' => $request->substract_amount_description]);

                    $alert = new PushNotify();
                    $alert->sendWalletAlert($request->user_id, $request->substract_amount, $request->substract_amount_description, $type = 'withdraw');

                    return redirect()->back()->with(['success' => config('settings.walletName') . ' Updated']);
                } catch (\Illuminate\Database\QueryException $qe) {
                    return redirect()->back()->with(['message' => $qe->getMessage()]);
                } catch (Exception $e) {
                    return redirect()->back()->with(['message' => $e->getMessage()]);
                } catch (\Throwable $th) {
                    return redirect()->back()->with(['message' => $th]);
                }
            } else {
                return redirect()->back()->with(['message' => 'Substract amount is less that the user balance amount.']);
            }

        }
    }

    public function walletTransactions()
    {
        $count = $transactions = Transaction::count();

        $transactions = Transaction::paginate(20);

        return view('admin.viewAllWalletTransactions', array(
            'transactions' => $transactions,
            'count' => $count,
        ));

    }
    /**
     * @param Request $request
     */
    public function searchWalletTransactions(Request $request)
    {
        $query = $request['query'];

        $transactions = Transaction::where('uuid', 'LIKE', '%' . $query . '%')
            ->paginate(20);

        $count = $transactions->total();

        return view('admin.viewAllWalletTransactions', array(
            'transactions' => $transactions,
            'query' => $query,
            'count' => $count,
        ));
    }

    /**
     * @param Request $request
     */
    public function cancelOrderFromAdmin(Request $request, TranslationHelper $translationHelper)
    {
        $keys = ['orderRefundWalletComment', 'orderPartialRefundWalletComment'];
        $translationData = $translationHelper->getDefaultLanguageValuesForKeys($keys);

        $order = Order::where('id', $request->order_id)->first();

        $user = User::where('id', $order->user_id)->first();

        try {
            //check if user is cancelling their own order...
            if ($order->orderstatus_id != 5 || $order->orderstatus_id != 6) {
                //check refund type
                // if refund_type === NOREFUND -> do nothing
                if ($request->refund_type === 'FULL') {
                    $user->deposit($order->total * 100, ['description' => $translationData->orderRefundWalletComment . $order->unique_order_id]);
                }

                if ($request->refund_type === 'HALF') {
                    $user->deposit($order->total / 2 * 100, ['description' => $translationData->orderPartialRefundWalletComment . $order->unique_order_id]);
                }

                //cancel order
                $order->orderstatus_id = 6; //6 means canceled..
                $order->save();

                //throw notification to user
                if (config('settings.enablePushNotificationOrders') == 'true') {
                    $notify = new PushNotify();
                    $notify->sendPushNotification('6', $order->user_id, $order->unique_order_id);
                }

                return redirect()->back()->with(['success' => 'Operation Successful']);
            }
        } catch (\Illuminate\Database\QueryException $qe) {
            return redirect()->back()->with(['message' => $qe->getMessage()]);
        } catch (Exception $e) {
            return redirect()->back()->with(['message' => $e->getMessage()]);
        } catch (\Throwable $th) {
            return redirect()->back()->with(['message' => $th]);
        }

    }

    /**
     * @param Request $request
     */
    public function acceptOrderFromAdmin(Request $request)
    {

        $order = Order::where('id', $request->id)->first();

        if ($order->orderstatus_id == '1') {
            $order->orderstatus_id = 2;
            $order->save();
            // Send SMS Notification to Delivery Guy
            if (config('settings.smsDeliveryNotify') == 'true') {
                //get restaurant
                $restaurant = Restaurant::where('id', $order->restaurant_id)->first();
                if ($restaurant) {
                    //get all pivot users of restaurant (delivery guy/ res owners)
                    $pivotUsers = $restaurant->users()
                        ->wherePivot('restaurant_id', $order->restaurant_id)
                        ->get();
                    //filter only res owner and send notification.
                    foreach ($pivotUsers as $pU) {
                        if ($pU->hasRole('Delivery Guy')) {
                            //send Notification to Delivery Guy
                            $message = config('settings.defaultSmsDeliveryMsg');
                            $otp = null;
                            $smsnotify = new Sms();
                            $smsnotify->processSmsAction('OD_NOTIFY', $pU->phone, $otp, $message);
                        }
                    }
                }
            }
            // END Send SMS Notification to Delivery Guy

            return redirect()->back()->with(array('success' => 'Order Accepted'));
        } else {
            return redirect()->back()->with(array('message' => 'Something went wrong.'));
        }
    }

    /**
     * @param Request $request
     */
    public function assignDeliveryFromAdmin(Request $request)
    {
        try {
            $assignment = new AcceptDelivery;
            $assignment->order_id = $request->order_id;
            $assignment->user_id = $request->user_id;
            $assignment->customer_id = $request->customer_id;
            $assignment->is_complete = 0;
            $assignment->created_at = Carbon::now();
            $assignment->updated_at = Carbon::now();
            $assignment->save();

            $order = Order::where('id', $request->order_id)->first();
            $order->orderstatus_id = 3;
            $order->save();
            return redirect()->back()->with(array('success' => 'Order Assigned'));
        } catch (Illuminate\Database\QueryException $e) {
            $errorCode = $e->errorInfo[1];
            if ($errorCode == 1062) {
                return redirect()->back()->with(array('message' => 'Something Went Wrong'));
            }
        }
    }

    /**
     * @param Request $request
     */
    public function reAssignDeliveryFromAdmin(Request $request)
    {

        $assignment = AcceptDelivery::where('order_id', $request->order_id)->first();
        $assignment->user_id = $request->user_id;
        $assignment->is_complete = 0;
        $assignment->updated_at = Carbon::now();
        $assignment->save();

        return redirect()->back()->with(array('success' => 'Order reassigned successfully'));
    }

    public function popularGeoLocations()
    {
        $locations = PopularGeoPlace::orderBy('id', 'DESC')->paginate(20);
        $locationsAll = PopularGeoPlace::all();
        $count = count($locationsAll);
        return view('admin.popularGeoLocations', array(
            'locations' => $locations,
            'count' => $count,
        ));
    }

    /**
     * @param Request $request
     */
    public function saveNewPopularGeoLocation(Request $request)
    {

        // dd($request->all());
        $location = new PopularGeoPlace();

        $location->name = $request->name;

        $location->latitude = $request->latitude;
        $location->longitude = $request->longitude;

        if ($request->is_active == 'true') {
            $location->is_active = true;
        } else {
            $location->is_active = false;
        }

        try {
            $location->save();
            return redirect()->back()->with(['success' => 'Location Saved']);
        } catch (\Illuminate\Database\QueryException $qe) {
            return redirect()->back()->with(['message' => $qe->getMessage()]);
        } catch (Exception $e) {
            return redirect()->back()->with(['message' => $e->getMessage()]);
        } catch (\Throwable $th) {
            return redirect()->back()->with(['message' => $th]);
        }
    }

    /**
     * @param $id
     */
    public function disablePopularGeoLocation($id)
    {
        $location = PopularGeoPlace::where('id', $id)->first();
        if ($location) {
            $location->toggleActive()->save();
            return redirect()->back()->with(['success' => 'Location Disabled']);
        } else {
            return redirect()->route('admin.popularGeoLocations');
        }
    }

    /**
     * @param $id
     */
    public function deletePopularGeoLocation($id)
    {
        $location = PopularGeoPlace::where('id', $id)->first();

        if ($location) {
            $location->delete();

            return redirect()->route('admin.popularGeoLocations')->with(['success' => 'Location Deleted']);
        } else {
            return redirect()->route('admin.popularGeoLocations');
        }
    }

    public function translations()
    {
        $translations = Translation::orderBy('id', 'DESC')->get();
        $count = count($translations);

        return view('admin.translations', array(
            'translations' => $translations,
            'count' => $count,
        ));
    }

    public function newTranslation()
    {
        return view('admin.newTranslation');
    }

    /**
     * @param Request $request
     */
    public function saveNewTranslation(Request $request)
    {
        // dd($request->all());
        // dd(json_encode($request->except(['language_name'])));

        $translation = new Translation();

        $translation->language_name = $request->language_name;
        $translation->data = json_encode($request->except(['language_name', '_token']));

        try {
            $translation->save();
            return redirect()->route('admin.translations')->with(['success' => 'Translation Created']);
        } catch (\Illuminate\Database\QueryException $qe) {
            return redirect()->back()->with(['message' => $qe->getMessage()]);
        } catch (Exception $e) {
            return redirect()->back()->with(['message' => $e->getMessage()]);
        } catch (\Throwable $th) {
            return redirect()->back()->with(['message' => $th]);
        }
    }

    /**
     * @param $id
     */
    public function editTranslation($id)
    {

        $translation = Translation::where('id', $id)->first();
        // dd(json_decode($translation->data));

        if ($translation) {
            return view('admin.editTranslation', array(
                'translation_id' => $translation->id,
                'language_name' => $translation->language_name,
                'data' => json_decode($translation->data),
            ));
        } else {
            return redirect()->route('admin.translations')->with(['message' => 'Translation Not Found']);
        }

    }
    /**
     * @param Request $request
     */
    public function updateTranslation(Request $request)
    {
        $translation = Translation::where('id', $request->translation_id)->first();

        $translation->language_name = $request->language_name;
        $translation->data = json_encode($request->except(['translation_id', 'language_name', '_token']));

        try {
            $translation->save();
            return redirect()->back()->with(['success' => 'Translation Updated']);
        } catch (\Illuminate\Database\QueryException $qe) {
            return redirect()->back()->with(['message' => $qe->getMessage()]);
        } catch (Exception $e) {
            return redirect()->back()->with(['message' => $e->getMessage()]);
        } catch (\Throwable $th) {
            return redirect()->back()->with(['message' => $th]);
        }

    }

    /**
     * @param $id
     */
    public function disableTranslation($id)
    {
        $translation = Translation::where('id', $id)->first();
        if ($translation) {
            $translation->toggleEnable()->save();
            return redirect()->back()->with(['success' => 'Operation Successful']);
        } else {
            return redirect()->route('admin.translations');
        }
    }

    /**
     * @param $id
     */
    public function deleteTranslation($id)
    {
        $translation = Translation::where('id', $id)->first();
        if ($translation) {
            $translation->delete();
            return redirect()->route('admin.translations')->with(['success' => 'Translation Deleted']);
        } else {
            return redirect()->route('admin.translations');
        }
    }

    /**
     * @param $id
     */
    public function makeDefaultLanguage($id)
    {
        $translation = Translation::where('id', $id)->first();
        if ($translation) {
            //remove default of other
            $currentDefaults = Translation::where('is_default', '1')->get();
            // dd($currentDefault);
            if (!empty($currentDefaults)) {
                foreach ($currentDefaults as $currentDefault) {
                    $currentDefault->is_default = 0;
                    $currentDefault->save();
                }
            }

            //make this default
            $translation->is_default = 1;
            $translation->save();
            return redirect()->back()->with(['success' => 'Operation Successful']);
        } else {
            return redirect()->route('admin.translations');
        }
    }

    /**
     * @param Request $request
     */
    public function updateRestaurantScheduleData(Request $request)
    {
        $data = $request->except(['_token', 'restaurant_id']);

        $i = 0;
        $str = '{';
        foreach ($data as $day => $times) {
            $str .= '"' . $day . '":[';
            if ($times) {
                foreach ($times as $key => $time) {

                    if ($key % 2 == 0) {
                        $t1 = $time;
                        $str .= '{"open" :' . '"' . $time . '"';

                    } else {
                        $t2 = $time;
                        $str .= '"close" :' . '"' . $time . '"}';
                    }

                    //check if last, if last then dont add comma,
                    if (count($times) != $key + 1) {
                        $str .= ',';
                    }
                }
                // dd($t1);
                if (Carbon::parse($t1) >= Carbon::parse($t2)) {

                    return redirect()->back()->with(['message' => 'Opening and Closing time is incorrect']);
                }
            } else {
                $str .= '}]';
            }

            if ($i != count($data) - 1) {
                $str .= '],';
            } else {
                $str .= ']';
            }
            $i++;
        }
        $str .= '}';

        // Fetches The Restaurant
        $restaurant = Restaurant::where('id', $request->restaurant_id)->first();
        // Enters The Data
        $restaurant->schedule_data = $str;
        // Saves the Data to Database
        $restaurant->save();

        return redirect()->back()->with(['success' => 'Scheduling data saved successfully']);

    }

    /**
     * @param $id
     */
    public function impersonate($id)
    {
        $user = User::where('id', $id)->first();
        if ($user && $user->hasRole('Store Owner')) {
            Auth::user()->impersonate($user);
            return redirect()->route('get.login');
        } else {
            return redirect()->route('admin.dashboard')->with(['message' => 'User not found']);
        }
    }
}
